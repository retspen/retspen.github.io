/* Generated */

#if defined(LIBXML_DOCB_ENABLED)
    { (char *)"docbDefaultSAXHandlerInit", libxml_docbDefaultSAXHandlerInit, METH_VARARGS, NULL },
#endif /* defined(LIBXML_DOCB_ENABLED) */
#if defined(LIBXML_HTML_ENABLED)
    { (char *)"htmlAutoCloseTag", libxml_htmlAutoCloseTag, METH_VARARGS, NULL },
#endif /* defined(LIBXML_HTML_ENABLED) */
#if defined(LIBXML_HTML_ENABLED)
    { (char *)"htmlCreateFileParserCtxt", libxml_htmlCreateFileParserCtxt, METH_VARARGS, NULL },
#endif /* defined(LIBXML_HTML_ENABLED) */
#if defined(LIBXML_HTML_ENABLED)
    { (char *)"htmlCreateMemoryParserCtxt", libxml_htmlCreateMemoryParserCtxt, METH_VARARGS, NULL },
#endif /* defined(LIBXML_HTML_ENABLED) */
#if defined(LIBXML_HTML_ENABLED)
    { (char *)"htmlCreatePushParser", libxml_htmlCreatePushParser, METH_VARARGS, NULL },
#endif
#if defined(LIBXML_HTML_ENABLED)
    { (char *)"htmlCtxtReadDoc", libxml_htmlCtxtReadDoc, METH_VARARGS, NULL },
#endif /* defined(LIBXML_HTML_ENABLED) */
#if defined(LIBXML_HTML_ENABLED)
    { (char *)"htmlCtxtReadFd", libxml_htmlCtxtReadFd, METH_VARARGS, NULL },
#endif /* defined(LIBXML_HTML_ENABLED) */
#if defined(LIBXML_HTML_ENABLED)
    { (char *)"htmlCtxtReadFile", libxml_htmlCtxtReadFile, METH_VARARGS, NULL },
#endif /* defined(LIBXML_HTML_ENABLED) */
#if defined(LIBXML_HTML_ENABLED)
    { (char *)"htmlCtxtReadMemory", libxml_htmlCtxtReadMemory, METH_VARARGS, NULL },
#endif /* defined(LIBXML_HTML_ENABLED) */
#if defined(LIBXML_HTML_ENABLED)
    { (char *)"htmlCtxtReset", libxml_htmlCtxtReset, METH_VARARGS, NULL },
#endif /* defined(LIBXML_HTML_ENABLED) */
#if defined(LIBXML_HTML_ENABLED)
    { (char *)"htmlCtxtUseOptions", libxml_htmlCtxtUseOptions, METH_VARARGS, NULL },
#endif /* defined(LIBXML_HTML_ENABLED) */
#if defined(LIBXML_HTML_ENABLED)
    { (char *)"htmlDefaultSAXHandlerInit", libxml_htmlDefaultSAXHandlerInit, METH_VARARGS, NULL },
#endif /* defined(LIBXML_HTML_ENABLED) */
#if defined(LIBXML_HTML_ENABLED) && defined(LIBXML_OUTPUT_ENABLED)
    { (char *)"htmlDocContentDumpFormatOutput", libxml_htmlDocContentDumpFormatOutput, METH_VARARGS, NULL },
#endif /* defined(LIBXML_HTML_ENABLED) && defined(LIBXML_OUTPUT_ENABLED) */
#if defined(LIBXML_HTML_ENABLED) && defined(LIBXML_OUTPUT_ENABLED)
    { (char *)"htmlDocContentDumpOutput", libxml_htmlDocContentDumpOutput, METH_VARARGS, NULL },
#endif /* defined(LIBXML_HTML_ENABLED) && defined(LIBXML_OUTPUT_ENABLED) */
#if defined(LIBXML_HTML_ENABLED) && defined(LIBXML_OUTPUT_ENABLED)
    { (char *)"htmlDocDump", libxml_htmlDocDump, METH_VARARGS, NULL },
#endif /* defined(LIBXML_HTML_ENABLED) && defined(LIBXML_OUTPUT_ENABLED) */
#if defined(LIBXML_HTML_ENABLED)
    { (char *)"htmlFreeParserCtxt", libxml_htmlFreeParserCtxt, METH_VARARGS, NULL },
#endif /* defined(LIBXML_HTML_ENABLED) */
#if defined(LIBXML_HTML_ENABLED)
    { (char *)"htmlGetMetaEncoding", libxml_htmlGetMetaEncoding, METH_VARARGS, NULL },
#endif /* defined(LIBXML_HTML_ENABLED) */
#if defined(LIBXML_HTML_ENABLED)
    { (char *)"htmlHandleOmittedElem", libxml_htmlHandleOmittedElem, METH_VARARGS, NULL },
#endif /* defined(LIBXML_HTML_ENABLED) */
#if defined(LIBXML_HTML_ENABLED)
    { (char *)"htmlInitAutoClose", libxml_htmlInitAutoClose, METH_VARARGS, NULL },
#endif /* defined(LIBXML_HTML_ENABLED) */
#if defined(LIBXML_HTML_ENABLED)
    { (char *)"htmlIsAutoClosed", libxml_htmlIsAutoClosed, METH_VARARGS, NULL },
#endif /* defined(LIBXML_HTML_ENABLED) */
#if defined(LIBXML_HTML_ENABLED)
    { (char *)"htmlIsBooleanAttr", libxml_htmlIsBooleanAttr, METH_VARARGS, NULL },
#endif /* defined(LIBXML_HTML_ENABLED) */
#if defined(LIBXML_HTML_ENABLED)
    { (char *)"htmlIsScriptAttribute", libxml_htmlIsScriptAttribute, METH_VARARGS, NULL },
#endif /* defined(LIBXML_HTML_ENABLED) */
#if defined(LIBXML_HTML_ENABLED)
    { (char *)"htmlNewDoc", libxml_htmlNewDoc, METH_VARARGS, NULL },
#endif /* defined(LIBXML_HTML_ENABLED) */
#if defined(LIBXML_HTML_ENABLED)
    { (char *)"htmlNewDocNoDtD", libxml_htmlNewDocNoDtD, METH_VARARGS, NULL },
#endif /* defined(LIBXML_HTML_ENABLED) */
#if defined(LIBXML_HTML_ENABLED)
    { (char *)"htmlNewParserCtxt", libxml_htmlNewParserCtxt, METH_VARARGS, NULL },
#endif /* defined(LIBXML_HTML_ENABLED) */
#if defined(LIBXML_HTML_ENABLED) && defined(LIBXML_OUTPUT_ENABLED)
    { (char *)"htmlNodeDumpFile", libxml_htmlNodeDumpFile, METH_VARARGS, NULL },
#endif /* defined(LIBXML_HTML_ENABLED) && defined(LIBXML_OUTPUT_ENABLED) */
#if defined(LIBXML_HTML_ENABLED) && defined(LIBXML_OUTPUT_ENABLED)
    { (char *)"htmlNodeDumpFileFormat", libxml_htmlNodeDumpFileFormat, METH_VARARGS, NULL },
#endif /* defined(LIBXML_HTML_ENABLED) && defined(LIBXML_OUTPUT_ENABLED) */
#if defined(LIBXML_HTML_ENABLED) && defined(LIBXML_OUTPUT_ENABLED)
    { (char *)"htmlNodeDumpFormatOutput", libxml_htmlNodeDumpFormatOutput, METH_VARARGS, NULL },
#endif /* defined(LIBXML_HTML_ENABLED) && defined(LIBXML_OUTPUT_ENABLED) */
#if defined(LIBXML_HTML_ENABLED) && defined(LIBXML_OUTPUT_ENABLED)
    { (char *)"htmlNodeDumpOutput", libxml_htmlNodeDumpOutput, METH_VARARGS, NULL },
#endif /* defined(LIBXML_HTML_ENABLED) && defined(LIBXML_OUTPUT_ENABLED) */
#if defined(LIBXML_HTML_ENABLED)
    { (char *)"htmlParseCharRef", libxml_htmlParseCharRef, METH_VARARGS, NULL },
#endif /* defined(LIBXML_HTML_ENABLED) */
#if defined(LIBXML_HTML_ENABLED) && defined(LIBXML_PUSH_ENABLED)
    { (char *)"htmlParseChunk", libxml_htmlParseChunk, METH_VARARGS, NULL },
#endif /* defined(LIBXML_HTML_ENABLED) && defined(LIBXML_PUSH_ENABLED) */
#if defined(LIBXML_HTML_ENABLED)
    { (char *)"htmlParseDoc", libxml_htmlParseDoc, METH_VARARGS, NULL },
#endif /* defined(LIBXML_HTML_ENABLED) */
#if defined(LIBXML_HTML_ENABLED)
    { (char *)"htmlParseDocument", libxml_htmlParseDocument, METH_VARARGS, NULL },
#endif /* defined(LIBXML_HTML_ENABLED) */
#if defined(LIBXML_HTML_ENABLED)
    { (char *)"htmlParseElement", libxml_htmlParseElement, METH_VARARGS, NULL },
#endif /* defined(LIBXML_HTML_ENABLED) */
#if defined(LIBXML_HTML_ENABLED)
    { (char *)"htmlParseFile", libxml_htmlParseFile, METH_VARARGS, NULL },
#endif /* defined(LIBXML_HTML_ENABLED) */
#if defined(LIBXML_HTML_ENABLED)
    { (char *)"htmlReadDoc", libxml_htmlReadDoc, METH_VARARGS, NULL },
#endif /* defined(LIBXML_HTML_ENABLED) */
#if defined(LIBXML_HTML_ENABLED)
    { (char *)"htmlReadFd", libxml_htmlReadFd, METH_VARARGS, NULL },
#endif /* defined(LIBXML_HTML_ENABLED) */
#if defined(LIBXML_HTML_ENABLED)
    { (char *)"htmlReadFile", libxml_htmlReadFile, METH_VARARGS, NULL },
#endif /* defined(LIBXML_HTML_ENABLED) */
#if defined(LIBXML_HTML_ENABLED)
    { (char *)"htmlReadMemory", libxml_htmlReadMemory, METH_VARARGS, NULL },
#endif /* defined(LIBXML_HTML_ENABLED) */
#if defined(LIBXML_HTML_ENABLED)
    { (char *)"htmlSAXParseFile", libxml_htmlSAXParseFile, METH_VARARGS, NULL },
#endif
#if defined(LIBXML_HTML_ENABLED) && defined(LIBXML_OUTPUT_ENABLED)
    { (char *)"htmlSaveFile", libxml_htmlSaveFile, METH_VARARGS, NULL },
#endif /* defined(LIBXML_HTML_ENABLED) && defined(LIBXML_OUTPUT_ENABLED) */
#if defined(LIBXML_HTML_ENABLED) && defined(LIBXML_OUTPUT_ENABLED)
    { (char *)"htmlSaveFileEnc", libxml_htmlSaveFileEnc, METH_VARARGS, NULL },
#endif /* defined(LIBXML_HTML_ENABLED) && defined(LIBXML_OUTPUT_ENABLED) */
#if defined(LIBXML_HTML_ENABLED) && defined(LIBXML_OUTPUT_ENABLED)
    { (char *)"htmlSaveFileFormat", libxml_htmlSaveFileFormat, METH_VARARGS, NULL },
#endif /* defined(LIBXML_HTML_ENABLED) && defined(LIBXML_OUTPUT_ENABLED) */
#if defined(LIBXML_HTML_ENABLED)
    { (char *)"htmlSetMetaEncoding", libxml_htmlSetMetaEncoding, METH_VARARGS, NULL },
#endif /* defined(LIBXML_HTML_ENABLED) */
    { (char *)"namePop", libxml_namePop, METH_VARARGS, NULL },
    { (char *)"namePush", libxml_namePush, METH_VARARGS, NULL },
    { (char *)"nodePop", libxml_nodePop, METH_VARARGS, NULL },
    { (char *)"nodePush", libxml_nodePush, METH_VARARGS, NULL },
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"valuePop", libxml_valuePop, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_CATALOG_ENABLED)
    { (char *)"xmlACatalogAdd", libxml_xmlACatalogAdd, METH_VARARGS, NULL },
#endif /* defined(LIBXML_CATALOG_ENABLED) */
#if defined(LIBXML_CATALOG_ENABLED) && defined(LIBXML_OUTPUT_ENABLED)
    { (char *)"xmlACatalogDump", libxml_xmlACatalogDump, METH_VARARGS, NULL },
#endif /* defined(LIBXML_CATALOG_ENABLED) && defined(LIBXML_OUTPUT_ENABLED) */
#if defined(LIBXML_CATALOG_ENABLED)
    { (char *)"xmlACatalogRemove", libxml_xmlACatalogRemove, METH_VARARGS, NULL },
#endif /* defined(LIBXML_CATALOG_ENABLED) */
#if defined(LIBXML_CATALOG_ENABLED)
    { (char *)"xmlACatalogResolve", libxml_xmlACatalogResolve, METH_VARARGS, NULL },
#endif /* defined(LIBXML_CATALOG_ENABLED) */
#if defined(LIBXML_CATALOG_ENABLED)
    { (char *)"xmlACatalogResolvePublic", libxml_xmlACatalogResolvePublic, METH_VARARGS, NULL },
#endif /* defined(LIBXML_CATALOG_ENABLED) */
#if defined(LIBXML_CATALOG_ENABLED)
    { (char *)"xmlACatalogResolveSystem", libxml_xmlACatalogResolveSystem, METH_VARARGS, NULL },
#endif /* defined(LIBXML_CATALOG_ENABLED) */
#if defined(LIBXML_CATALOG_ENABLED)
    { (char *)"xmlACatalogResolveURI", libxml_xmlACatalogResolveURI, METH_VARARGS, NULL },
#endif /* defined(LIBXML_CATALOG_ENABLED) */
    { (char *)"xmlAddChild", libxml_xmlAddChild, METH_VARARGS, NULL },
    { (char *)"xmlAddChildList", libxml_xmlAddChildList, METH_VARARGS, NULL },
    { (char *)"xmlAddDocEntity", libxml_xmlAddDocEntity, METH_VARARGS, NULL },
    { (char *)"xmlAddDtdEntity", libxml_xmlAddDtdEntity, METH_VARARGS, NULL },
    { (char *)"xmlAddEncodingAlias", libxml_xmlAddEncodingAlias, METH_VARARGS, NULL },
    { (char *)"xmlAddNextSibling", libxml_xmlAddNextSibling, METH_VARARGS, NULL },
#if defined(LIBXML_TREE_ENABLED) || defined(LIBXML_HTML_ENABLED) || defined(LIBXML_SCHEMAS_ENABLED)
    { (char *)"xmlAddPrevSibling", libxml_xmlAddPrevSibling, METH_VARARGS, NULL },
#endif /* defined(LIBXML_TREE_ENABLED) || defined(LIBXML_HTML_ENABLED) || defined(LIBXML_SCHEMAS_ENABLED) */
    { (char *)"xmlAddSibling", libxml_xmlAddSibling, METH_VARARGS, NULL },
#if defined(LIBXML_DEBUG_ENABLED)
    { (char *)"xmlBoolToText", libxml_xmlBoolToText, METH_VARARGS, NULL },
#endif /* defined(LIBXML_DEBUG_ENABLED) */
    { (char *)"xmlBuildQName", libxml_xmlBuildQName, METH_VARARGS, NULL },
    { (char *)"xmlBuildRelativeURI", libxml_xmlBuildRelativeURI, METH_VARARGS, NULL },
    { (char *)"xmlBuildURI", libxml_xmlBuildURI, METH_VARARGS, NULL },
    { (char *)"xmlByteConsumed", libxml_xmlByteConsumed, METH_VARARGS, NULL },
    { (char *)"xmlCanonicPath", libxml_xmlCanonicPath, METH_VARARGS, NULL },
#if defined(LIBXML_CATALOG_ENABLED)
    { (char *)"xmlCatalogAdd", libxml_xmlCatalogAdd, METH_VARARGS, NULL },
#endif /* defined(LIBXML_CATALOG_ENABLED) */
#if defined(LIBXML_CATALOG_ENABLED)
    { (char *)"xmlCatalogCleanup", libxml_xmlCatalogCleanup, METH_VARARGS, NULL },
#endif /* defined(LIBXML_CATALOG_ENABLED) */
#if defined(LIBXML_CATALOG_ENABLED)
    { (char *)"xmlCatalogConvert", libxml_xmlCatalogConvert, METH_VARARGS, NULL },
#endif /* defined(LIBXML_CATALOG_ENABLED) */
#if defined(LIBXML_CATALOG_ENABLED) && defined(LIBXML_OUTPUT_ENABLED)
    { (char *)"xmlCatalogDump", libxml_xmlCatalogDump, METH_VARARGS, NULL },
#endif /* defined(LIBXML_CATALOG_ENABLED) && defined(LIBXML_OUTPUT_ENABLED) */
#if defined(LIBXML_CATALOG_ENABLED)
    { (char *)"xmlCatalogGetPublic", libxml_xmlCatalogGetPublic, METH_VARARGS, NULL },
#endif /* defined(LIBXML_CATALOG_ENABLED) */
#if defined(LIBXML_CATALOG_ENABLED)
    { (char *)"xmlCatalogGetSystem", libxml_xmlCatalogGetSystem, METH_VARARGS, NULL },
#endif /* defined(LIBXML_CATALOG_ENABLED) */
#if defined(LIBXML_CATALOG_ENABLED)
    { (char *)"xmlCatalogIsEmpty", libxml_xmlCatalogIsEmpty, METH_VARARGS, NULL },
#endif /* defined(LIBXML_CATALOG_ENABLED) */
#if defined(LIBXML_CATALOG_ENABLED)
    { (char *)"xmlCatalogRemove", libxml_xmlCatalogRemove, METH_VARARGS, NULL },
#endif /* defined(LIBXML_CATALOG_ENABLED) */
#if defined(LIBXML_CATALOG_ENABLED)
    { (char *)"xmlCatalogResolve", libxml_xmlCatalogResolve, METH_VARARGS, NULL },
#endif /* defined(LIBXML_CATALOG_ENABLED) */
#if defined(LIBXML_CATALOG_ENABLED)
    { (char *)"xmlCatalogResolvePublic", libxml_xmlCatalogResolvePublic, METH_VARARGS, NULL },
#endif /* defined(LIBXML_CATALOG_ENABLED) */
#if defined(LIBXML_CATALOG_ENABLED)
    { (char *)"xmlCatalogResolveSystem", libxml_xmlCatalogResolveSystem, METH_VARARGS, NULL },
#endif /* defined(LIBXML_CATALOG_ENABLED) */
#if defined(LIBXML_CATALOG_ENABLED)
    { (char *)"xmlCatalogResolveURI", libxml_xmlCatalogResolveURI, METH_VARARGS, NULL },
#endif /* defined(LIBXML_CATALOG_ENABLED) */
#if defined(LIBXML_CATALOG_ENABLED)
    { (char *)"xmlCatalogSetDebug", libxml_xmlCatalogSetDebug, METH_VARARGS, NULL },
#endif /* defined(LIBXML_CATALOG_ENABLED) */
    { (char *)"xmlCharStrdup", libxml_xmlCharStrdup, METH_VARARGS, NULL },
    { (char *)"xmlCharStrndup", libxml_xmlCharStrndup, METH_VARARGS, NULL },
    { (char *)"xmlCheckFilename", libxml_xmlCheckFilename, METH_VARARGS, NULL },
    { (char *)"xmlCheckLanguageID", libxml_xmlCheckLanguageID, METH_VARARGS, NULL },
    { (char *)"xmlCheckUTF8", libxml_xmlCheckUTF8, METH_VARARGS, NULL },
    { (char *)"xmlCheckVersion", libxml_xmlCheckVersion, METH_VARARGS, NULL },
    { (char *)"xmlCleanupCharEncodingHandlers", libxml_xmlCleanupCharEncodingHandlers, METH_VARARGS, NULL },
    { (char *)"xmlCleanupEncodingAliases", libxml_xmlCleanupEncodingAliases, METH_VARARGS, NULL },
    { (char *)"xmlCleanupGlobals", libxml_xmlCleanupGlobals, METH_VARARGS, NULL },
    { (char *)"xmlCleanupInputCallbacks", libxml_xmlCleanupInputCallbacks, METH_VARARGS, NULL },
#if defined(LIBXML_OUTPUT_ENABLED)
    { (char *)"xmlCleanupOutputCallbacks", libxml_xmlCleanupOutputCallbacks, METH_VARARGS, NULL },
#endif /* defined(LIBXML_OUTPUT_ENABLED) */
#if defined(LIBXML_LEGACY_ENABLED)
    { (char *)"xmlCleanupPredefinedEntities", libxml_xmlCleanupPredefinedEntities, METH_VARARGS, NULL },
#endif /* defined(LIBXML_LEGACY_ENABLED) */
    { (char *)"xmlClearParserCtxt", libxml_xmlClearParserCtxt, METH_VARARGS, NULL },
#if defined(LIBXML_CATALOG_ENABLED)
    { (char *)"xmlConvertSGMLCatalog", libxml_xmlConvertSGMLCatalog, METH_VARARGS, NULL },
#endif /* defined(LIBXML_CATALOG_ENABLED) */
    { (char *)"xmlCopyChar", libxml_xmlCopyChar, METH_VARARGS, NULL },
    { (char *)"xmlCopyCharMultiByte", libxml_xmlCopyCharMultiByte, METH_VARARGS, NULL },
#if defined(LIBXML_TREE_ENABLED) || defined(LIBXML_SCHEMAS_ENABLED)
    { (char *)"xmlCopyDoc", libxml_xmlCopyDoc, METH_VARARGS, NULL },
#endif /* defined(LIBXML_TREE_ENABLED) || defined(LIBXML_SCHEMAS_ENABLED) */
#if defined(LIBXML_TREE_ENABLED)
    { (char *)"xmlCopyDtd", libxml_xmlCopyDtd, METH_VARARGS, NULL },
#endif /* defined(LIBXML_TREE_ENABLED) */
    { (char *)"xmlCopyError", libxml_xmlCopyError, METH_VARARGS, NULL },
    { (char *)"xmlCopyNamespace", libxml_xmlCopyNamespace, METH_VARARGS, NULL },
    { (char *)"xmlCopyNamespaceList", libxml_xmlCopyNamespaceList, METH_VARARGS, NULL },
    { (char *)"xmlCopyNode", libxml_xmlCopyNode, METH_VARARGS, NULL },
    { (char *)"xmlCopyNodeList", libxml_xmlCopyNodeList, METH_VARARGS, NULL },
    { (char *)"xmlCopyProp", libxml_xmlCopyProp, METH_VARARGS, NULL },
    { (char *)"xmlCopyPropList", libxml_xmlCopyPropList, METH_VARARGS, NULL },
    { (char *)"xmlCreateDocParserCtxt", libxml_xmlCreateDocParserCtxt, METH_VARARGS, NULL },
    { (char *)"xmlCreateEntityParserCtxt", libxml_xmlCreateEntityParserCtxt, METH_VARARGS, NULL },
    { (char *)"xmlCreateFileParserCtxt", libxml_xmlCreateFileParserCtxt, METH_VARARGS, NULL },
    { (char *)"xmlCreateInputBuffer", libxml_xmlCreateInputBuffer, METH_VARARGS, NULL },
    { (char *)"xmlCreateIntSubset", libxml_xmlCreateIntSubset, METH_VARARGS, NULL },
    { (char *)"xmlCreateMemoryParserCtxt", libxml_xmlCreateMemoryParserCtxt, METH_VARARGS, NULL },
    { (char *)"xmlCreateOutputBuffer", libxml_xmlCreateOutputBuffer, METH_VARARGS, NULL },
    { (char *)"xmlCreatePushParser", libxml_xmlCreatePushParser, METH_VARARGS, NULL },
    { (char *)"xmlCreateURI", libxml_xmlCreateURI, METH_VARARGS, NULL },
    { (char *)"xmlCreateURLParserCtxt", libxml_xmlCreateURLParserCtxt, METH_VARARGS, NULL },
    { (char *)"xmlCtxtReadDoc", libxml_xmlCtxtReadDoc, METH_VARARGS, NULL },
    { (char *)"xmlCtxtReadFd", libxml_xmlCtxtReadFd, METH_VARARGS, NULL },
    { (char *)"xmlCtxtReadFile", libxml_xmlCtxtReadFile, METH_VARARGS, NULL },
    { (char *)"xmlCtxtReadMemory", libxml_xmlCtxtReadMemory, METH_VARARGS, NULL },
    { (char *)"xmlCtxtReset", libxml_xmlCtxtReset, METH_VARARGS, NULL },
    { (char *)"xmlCtxtResetPush", libxml_xmlCtxtResetPush, METH_VARARGS, NULL },
    { (char *)"xmlCtxtUseOptions", libxml_xmlCtxtUseOptions, METH_VARARGS, NULL },
#if defined(LIBXML_DEBUG_ENABLED)
    { (char *)"xmlDebugCheckDocument", libxml_xmlDebugCheckDocument, METH_VARARGS, NULL },
#endif /* defined(LIBXML_DEBUG_ENABLED) */
#if defined(LIBXML_DEBUG_ENABLED)
    { (char *)"xmlDebugDumpAttr", libxml_xmlDebugDumpAttr, METH_VARARGS, NULL },
#endif /* defined(LIBXML_DEBUG_ENABLED) */
#if defined(LIBXML_DEBUG_ENABLED)
    { (char *)"xmlDebugDumpAttrList", libxml_xmlDebugDumpAttrList, METH_VARARGS, NULL },
#endif /* defined(LIBXML_DEBUG_ENABLED) */
#if defined(LIBXML_DEBUG_ENABLED)
    { (char *)"xmlDebugDumpDTD", libxml_xmlDebugDumpDTD, METH_VARARGS, NULL },
#endif /* defined(LIBXML_DEBUG_ENABLED) */
#if defined(LIBXML_DEBUG_ENABLED)
    { (char *)"xmlDebugDumpDocument", libxml_xmlDebugDumpDocument, METH_VARARGS, NULL },
#endif /* defined(LIBXML_DEBUG_ENABLED) */
#if defined(LIBXML_DEBUG_ENABLED)
    { (char *)"xmlDebugDumpDocumentHead", libxml_xmlDebugDumpDocumentHead, METH_VARARGS, NULL },
#endif /* defined(LIBXML_DEBUG_ENABLED) */
#if defined(LIBXML_DEBUG_ENABLED)
    { (char *)"xmlDebugDumpEntities", libxml_xmlDebugDumpEntities, METH_VARARGS, NULL },
#endif /* defined(LIBXML_DEBUG_ENABLED) */
#if defined(LIBXML_DEBUG_ENABLED)
    { (char *)"xmlDebugDumpNode", libxml_xmlDebugDumpNode, METH_VARARGS, NULL },
#endif /* defined(LIBXML_DEBUG_ENABLED) */
#if defined(LIBXML_DEBUG_ENABLED)
    { (char *)"xmlDebugDumpNodeList", libxml_xmlDebugDumpNodeList, METH_VARARGS, NULL },
#endif /* defined(LIBXML_DEBUG_ENABLED) */
#if defined(LIBXML_DEBUG_ENABLED)
    { (char *)"xmlDebugDumpOneNode", libxml_xmlDebugDumpOneNode, METH_VARARGS, NULL },
#endif /* defined(LIBXML_DEBUG_ENABLED) */
#if defined(LIBXML_DEBUG_ENABLED)
    { (char *)"xmlDebugDumpString", libxml_xmlDebugDumpString, METH_VARARGS, NULL },
#endif /* defined(LIBXML_DEBUG_ENABLED) */
    { (char *)"xmlDebugMemory", libxml_xmlDebugMemory, METH_VARARGS, NULL },
#if defined(LIBXML_LEGACY_ENABLED)
    { (char *)"xmlDecodeEntities", libxml_xmlDecodeEntities, METH_VARARGS, NULL },
#endif /* defined(LIBXML_LEGACY_ENABLED) */
    { (char *)"xmlDefaultSAXHandlerInit", libxml_xmlDefaultSAXHandlerInit, METH_VARARGS, NULL },
    { (char *)"xmlDelEncodingAlias", libxml_xmlDelEncodingAlias, METH_VARARGS, NULL },
    { (char *)"xmlDictCleanup", libxml_xmlDictCleanup, METH_VARARGS, NULL },
    { (char *)"xmlDocCopyNode", libxml_xmlDocCopyNode, METH_VARARGS, NULL },
    { (char *)"xmlDocCopyNodeList", libxml_xmlDocCopyNodeList, METH_VARARGS, NULL },
#if defined(LIBXML_OUTPUT_ENABLED)
    { (char *)"xmlDocDump", libxml_xmlDocDump, METH_VARARGS, NULL },
#endif /* defined(LIBXML_OUTPUT_ENABLED) */
#if defined(LIBXML_OUTPUT_ENABLED)
    { (char *)"xmlDocFormatDump", libxml_xmlDocFormatDump, METH_VARARGS, NULL },
#endif /* defined(LIBXML_OUTPUT_ENABLED) */
    { (char *)"xmlDocGetRootElement", libxml_xmlDocGetRootElement, METH_VARARGS, NULL },
#if defined(LIBXML_TREE_ENABLED) || defined(LIBXML_WRITER_ENABLED)
    { (char *)"xmlDocSetRootElement", libxml_xmlDocSetRootElement, METH_VARARGS, NULL },
#endif /* defined(LIBXML_TREE_ENABLED) || defined(LIBXML_WRITER_ENABLED) */
    { (char *)"xmlDumpMemory", libxml_xmlDumpMemory, METH_VARARGS, NULL },
#if defined(LIBXML_OUTPUT_ENABLED)
    { (char *)"xmlElemDump", libxml_xmlElemDump, METH_VARARGS, NULL },
#endif /* defined(LIBXML_OUTPUT_ENABLED) */
#if defined(LIBXML_LEGACY_ENABLED)
    { (char *)"xmlEncodeEntities", libxml_xmlEncodeEntities, METH_VARARGS, NULL },
#endif /* defined(LIBXML_LEGACY_ENABLED) */
    { (char *)"xmlEncodeEntitiesReentrant", libxml_xmlEncodeEntitiesReentrant, METH_VARARGS, NULL },
    { (char *)"xmlEncodeSpecialChars", libxml_xmlEncodeSpecialChars, METH_VARARGS, NULL },
    { (char *)"xmlErrorGetCode", libxml_xmlErrorGetCode, METH_VARARGS, NULL },
    { (char *)"xmlErrorGetDomain", libxml_xmlErrorGetDomain, METH_VARARGS, NULL },
    { (char *)"xmlErrorGetFile", libxml_xmlErrorGetFile, METH_VARARGS, NULL },
    { (char *)"xmlErrorGetLevel", libxml_xmlErrorGetLevel, METH_VARARGS, NULL },
    { (char *)"xmlErrorGetLine", libxml_xmlErrorGetLine, METH_VARARGS, NULL },
    { (char *)"xmlErrorGetMessage", libxml_xmlErrorGetMessage, METH_VARARGS, NULL },
    { (char *)"xmlFileMatch", libxml_xmlFileMatch, METH_VARARGS, NULL },
#if defined(LIBXML_TREE_ENABLED)
    { (char *)"xmlFirstElementChild", libxml_xmlFirstElementChild, METH_VARARGS, NULL },
#endif /* defined(LIBXML_TREE_ENABLED) */
#if defined(LIBXML_CATALOG_ENABLED)
    { (char *)"xmlFreeCatalog", libxml_xmlFreeCatalog, METH_VARARGS, NULL },
#endif /* defined(LIBXML_CATALOG_ENABLED) */
    { (char *)"xmlFreeDoc", libxml_xmlFreeDoc, METH_VARARGS, NULL },
    { (char *)"xmlFreeDtd", libxml_xmlFreeDtd, METH_VARARGS, NULL },
    { (char *)"xmlFreeNode", libxml_xmlFreeNode, METH_VARARGS, NULL },
    { (char *)"xmlFreeNodeList", libxml_xmlFreeNodeList, METH_VARARGS, NULL },
    { (char *)"xmlFreeNs", libxml_xmlFreeNs, METH_VARARGS, NULL },
    { (char *)"xmlFreeNsList", libxml_xmlFreeNsList, METH_VARARGS, NULL },
    { (char *)"xmlFreeParserInputBuffer", libxml_xmlFreeParserInputBuffer, METH_VARARGS, NULL },
    { (char *)"xmlFreeProp", libxml_xmlFreeProp, METH_VARARGS, NULL },
    { (char *)"xmlFreePropList", libxml_xmlFreePropList, METH_VARARGS, NULL },
    { (char *)"xmlFreeURI", libxml_xmlFreeURI, METH_VARARGS, NULL },
    { (char *)"xmlGetCompressMode", libxml_xmlGetCompressMode, METH_VARARGS, NULL },
    { (char *)"xmlGetDocCompressMode", libxml_xmlGetDocCompressMode, METH_VARARGS, NULL },
    { (char *)"xmlGetDocEntity", libxml_xmlGetDocEntity, METH_VARARGS, NULL },
    { (char *)"xmlGetDtdAttrDesc", libxml_xmlGetDtdAttrDesc, METH_VARARGS, NULL },
    { (char *)"xmlGetDtdElementDesc", libxml_xmlGetDtdElementDesc, METH_VARARGS, NULL },
    { (char *)"xmlGetDtdEntity", libxml_xmlGetDtdEntity, METH_VARARGS, NULL },
    { (char *)"xmlGetDtdQAttrDesc", libxml_xmlGetDtdQAttrDesc, METH_VARARGS, NULL },
    { (char *)"xmlGetDtdQElementDesc", libxml_xmlGetDtdQElementDesc, METH_VARARGS, NULL },
    { (char *)"xmlGetEncodingAlias", libxml_xmlGetEncodingAlias, METH_VARARGS, NULL },
    { (char *)"xmlGetID", libxml_xmlGetID, METH_VARARGS, NULL },
    { (char *)"xmlGetIntSubset", libxml_xmlGetIntSubset, METH_VARARGS, NULL },
    { (char *)"xmlGetLastChild", libxml_xmlGetLastChild, METH_VARARGS, NULL },
    { (char *)"xmlGetLastError", libxml_xmlGetLastError, METH_VARARGS, NULL },
    { (char *)"xmlGetLineNo", libxml_xmlGetLineNo, METH_VARARGS, NULL },
    { (char *)"xmlGetNoNsProp", libxml_xmlGetNoNsProp, METH_VARARGS, NULL },
#if defined(LIBXML_TREE_ENABLED) || defined(LIBXML_DEBUG_ENABLED)
    { (char *)"xmlGetNodePath", libxml_xmlGetNodePath, METH_VARARGS, NULL },
#endif /* defined(LIBXML_TREE_ENABLED) || defined(LIBXML_DEBUG_ENABLED) */
    { (char *)"xmlGetNsProp", libxml_xmlGetNsProp, METH_VARARGS, NULL },
    { (char *)"xmlGetParameterEntity", libxml_xmlGetParameterEntity, METH_VARARGS, NULL },
    { (char *)"xmlGetPredefinedEntity", libxml_xmlGetPredefinedEntity, METH_VARARGS, NULL },
    { (char *)"xmlGetProp", libxml_xmlGetProp, METH_VARARGS, NULL },
#if defined(LIBXML_LEGACY_ENABLED)
    { (char *)"xmlHandleEntity", libxml_xmlHandleEntity, METH_VARARGS, NULL },
#endif /* defined(LIBXML_LEGACY_ENABLED) */
    { (char *)"xmlHasNsProp", libxml_xmlHasNsProp, METH_VARARGS, NULL },
    { (char *)"xmlHasProp", libxml_xmlHasProp, METH_VARARGS, NULL },
#if defined(LIBXML_FTP_ENABLED)
    { (char *)"xmlIOFTPMatch", libxml_xmlIOFTPMatch, METH_VARARGS, NULL },
#endif /* defined(LIBXML_FTP_ENABLED) */
#if defined(LIBXML_HTTP_ENABLED)
    { (char *)"xmlIOHTTPMatch", libxml_xmlIOHTTPMatch, METH_VARARGS, NULL },
#endif /* defined(LIBXML_HTTP_ENABLED) */
    { (char *)"xmlInitCharEncodingHandlers", libxml_xmlInitCharEncodingHandlers, METH_VARARGS, NULL },
    { (char *)"xmlInitGlobals", libxml_xmlInitGlobals, METH_VARARGS, NULL },
    { (char *)"xmlInitParser", libxml_xmlInitParser, METH_VARARGS, NULL },
    { (char *)"xmlInitParserCtxt", libxml_xmlInitParserCtxt, METH_VARARGS, NULL },
#if defined(LIBXML_CATALOG_ENABLED)
    { (char *)"xmlInitializeCatalog", libxml_xmlInitializeCatalog, METH_VARARGS, NULL },
#endif /* defined(LIBXML_CATALOG_ENABLED) */
    { (char *)"xmlInitializeDict", libxml_xmlInitializeDict, METH_VARARGS, NULL },
#if defined(LIBXML_LEGACY_ENABLED)
    { (char *)"xmlInitializePredefinedEntities", libxml_xmlInitializePredefinedEntities, METH_VARARGS, NULL },
#endif /* defined(LIBXML_LEGACY_ENABLED) */
    { (char *)"xmlIsBaseChar", libxml_xmlIsBaseChar, METH_VARARGS, NULL },
    { (char *)"xmlIsBlank", libxml_xmlIsBlank, METH_VARARGS, NULL },
    { (char *)"xmlIsBlankNode", libxml_xmlIsBlankNode, METH_VARARGS, NULL },
    { (char *)"xmlIsChar", libxml_xmlIsChar, METH_VARARGS, NULL },
    { (char *)"xmlIsCombining", libxml_xmlIsCombining, METH_VARARGS, NULL },
    { (char *)"xmlIsDigit", libxml_xmlIsDigit, METH_VARARGS, NULL },
    { (char *)"xmlIsExtender", libxml_xmlIsExtender, METH_VARARGS, NULL },
    { (char *)"xmlIsID", libxml_xmlIsID, METH_VARARGS, NULL },
    { (char *)"xmlIsIdeographic", libxml_xmlIsIdeographic, METH_VARARGS, NULL },
    { (char *)"xmlIsLetter", libxml_xmlIsLetter, METH_VARARGS, NULL },
    { (char *)"xmlIsMixedElement", libxml_xmlIsMixedElement, METH_VARARGS, NULL },
    { (char *)"xmlIsPubidChar", libxml_xmlIsPubidChar, METH_VARARGS, NULL },
    { (char *)"xmlIsRef", libxml_xmlIsRef, METH_VARARGS, NULL },
    { (char *)"xmlIsXHTML", libxml_xmlIsXHTML, METH_VARARGS, NULL },
    { (char *)"xmlKeepBlanksDefault", libxml_xmlKeepBlanksDefault, METH_VARARGS, NULL },
#if defined(LIBXML_TREE_ENABLED)
    { (char *)"xmlLastElementChild", libxml_xmlLastElementChild, METH_VARARGS, NULL },
#endif /* defined(LIBXML_TREE_ENABLED) */
    { (char *)"xmlLineNumbersDefault", libxml_xmlLineNumbersDefault, METH_VARARGS, NULL },
#if defined(LIBXML_CATALOG_ENABLED)
    { (char *)"xmlLoadACatalog", libxml_xmlLoadACatalog, METH_VARARGS, NULL },
#endif /* defined(LIBXML_CATALOG_ENABLED) */
#if defined(LIBXML_CATALOG_ENABLED)
    { (char *)"xmlLoadCatalog", libxml_xmlLoadCatalog, METH_VARARGS, NULL },
#endif /* defined(LIBXML_CATALOG_ENABLED) */
#if defined(LIBXML_CATALOG_ENABLED)
    { (char *)"xmlLoadCatalogs", libxml_xmlLoadCatalogs, METH_VARARGS, NULL },
#endif /* defined(LIBXML_CATALOG_ENABLED) */
#if defined(LIBXML_CATALOG_ENABLED)
    { (char *)"xmlLoadSGMLSuperCatalog", libxml_xmlLoadSGMLSuperCatalog, METH_VARARGS, NULL },
#endif /* defined(LIBXML_CATALOG_ENABLED) */
#if defined(LIBXML_DEBUG_ENABLED)
    { (char *)"xmlLsCountNode", libxml_xmlLsCountNode, METH_VARARGS, NULL },
#endif /* defined(LIBXML_DEBUG_ENABLED) */
#if defined(LIBXML_DEBUG_ENABLED)
    { (char *)"xmlLsOneNode", libxml_xmlLsOneNode, METH_VARARGS, NULL },
#endif /* defined(LIBXML_DEBUG_ENABLED) */
    { (char *)"xmlMemoryUsed", libxml_xmlMemoryUsed, METH_VARARGS, NULL },
#if defined(LIBXML_LEGACY_ENABLED)
    { (char *)"xmlNamespaceParseNCName", libxml_xmlNamespaceParseNCName, METH_VARARGS, NULL },
#endif /* defined(LIBXML_LEGACY_ENABLED) */
#if defined(LIBXML_LEGACY_ENABLED)
    { (char *)"xmlNamespaceParseNSDef", libxml_xmlNamespaceParseNSDef, METH_VARARGS, NULL },
#endif /* defined(LIBXML_LEGACY_ENABLED) */
#if defined(LIBXML_FTP_ENABLED)
    { (char *)"xmlNanoFTPCleanup", libxml_xmlNanoFTPCleanup, METH_VARARGS, NULL },
#endif /* defined(LIBXML_FTP_ENABLED) */
#if defined(LIBXML_FTP_ENABLED)
    { (char *)"xmlNanoFTPInit", libxml_xmlNanoFTPInit, METH_VARARGS, NULL },
#endif /* defined(LIBXML_FTP_ENABLED) */
#if defined(LIBXML_FTP_ENABLED)
    { (char *)"xmlNanoFTPProxy", libxml_xmlNanoFTPProxy, METH_VARARGS, NULL },
#endif /* defined(LIBXML_FTP_ENABLED) */
#if defined(LIBXML_FTP_ENABLED)
    { (char *)"xmlNanoFTPScanProxy", libxml_xmlNanoFTPScanProxy, METH_VARARGS, NULL },
#endif /* defined(LIBXML_FTP_ENABLED) */
#if defined(LIBXML_HTTP_ENABLED)
    { (char *)"xmlNanoHTTPCleanup", libxml_xmlNanoHTTPCleanup, METH_VARARGS, NULL },
#endif /* defined(LIBXML_HTTP_ENABLED) */
#if defined(LIBXML_HTTP_ENABLED)
    { (char *)"xmlNanoHTTPInit", libxml_xmlNanoHTTPInit, METH_VARARGS, NULL },
#endif /* defined(LIBXML_HTTP_ENABLED) */
#if defined(LIBXML_HTTP_ENABLED)
    { (char *)"xmlNanoHTTPScanProxy", libxml_xmlNanoHTTPScanProxy, METH_VARARGS, NULL },
#endif /* defined(LIBXML_HTTP_ENABLED) */
    { (char *)"xmlNewCDataBlock", libxml_xmlNewCDataBlock, METH_VARARGS, NULL },
#if defined(LIBXML_CATALOG_ENABLED)
    { (char *)"xmlNewCatalog", libxml_xmlNewCatalog, METH_VARARGS, NULL },
#endif /* defined(LIBXML_CATALOG_ENABLED) */
    { (char *)"xmlNewCharRef", libxml_xmlNewCharRef, METH_VARARGS, NULL },
#if defined(LIBXML_TREE_ENABLED) || defined(LIBXML_SCHEMAS_ENABLED)
    { (char *)"xmlNewChild", libxml_xmlNewChild, METH_VARARGS, NULL },
#endif /* defined(LIBXML_TREE_ENABLED) || defined(LIBXML_SCHEMAS_ENABLED) */
    { (char *)"xmlNewComment", libxml_xmlNewComment, METH_VARARGS, NULL },
    { (char *)"xmlNewDoc", libxml_xmlNewDoc, METH_VARARGS, NULL },
    { (char *)"xmlNewDocComment", libxml_xmlNewDocComment, METH_VARARGS, NULL },
#if defined(LIBXML_TREE_ENABLED)
    { (char *)"xmlNewDocFragment", libxml_xmlNewDocFragment, METH_VARARGS, NULL },
#endif /* defined(LIBXML_TREE_ENABLED) */
    { (char *)"xmlNewDocNode", libxml_xmlNewDocNode, METH_VARARGS, NULL },
    { (char *)"xmlNewDocNodeEatName", libxml_xmlNewDocNodeEatName, METH_VARARGS, NULL },
    { (char *)"xmlNewDocPI", libxml_xmlNewDocPI, METH_VARARGS, NULL },
    { (char *)"xmlNewDocProp", libxml_xmlNewDocProp, METH_VARARGS, NULL },
#if defined(LIBXML_TREE_ENABLED)
    { (char *)"xmlNewDocRawNode", libxml_xmlNewDocRawNode, METH_VARARGS, NULL },
#endif /* defined(LIBXML_TREE_ENABLED) */
    { (char *)"xmlNewDocText", libxml_xmlNewDocText, METH_VARARGS, NULL },
    { (char *)"xmlNewDocTextLen", libxml_xmlNewDocTextLen, METH_VARARGS, NULL },
    { (char *)"xmlNewDtd", libxml_xmlNewDtd, METH_VARARGS, NULL },
    { (char *)"xmlNewEntity", libxml_xmlNewEntity, METH_VARARGS, NULL },
#if defined(LIBXML_LEGACY_ENABLED)
    { (char *)"xmlNewGlobalNs", libxml_xmlNewGlobalNs, METH_VARARGS, NULL },
#endif /* defined(LIBXML_LEGACY_ENABLED) */
    { (char *)"xmlNewNode", libxml_xmlNewNode, METH_VARARGS, NULL },
    { (char *)"xmlNewNodeEatName", libxml_xmlNewNodeEatName, METH_VARARGS, NULL },
    { (char *)"xmlNewNs", libxml_xmlNewNs, METH_VARARGS, NULL },
    { (char *)"xmlNewNsProp", libxml_xmlNewNsProp, METH_VARARGS, NULL },
    { (char *)"xmlNewNsPropEatName", libxml_xmlNewNsPropEatName, METH_VARARGS, NULL },
    { (char *)"xmlNewPI", libxml_xmlNewPI, METH_VARARGS, NULL },
    { (char *)"xmlNewParserCtxt", libxml_xmlNewParserCtxt, METH_VARARGS, NULL },
#if defined(LIBXML_TREE_ENABLED) || defined(LIBXML_HTML_ENABLED) || defined(LIBXML_SCHEMAS_ENABLED)
    { (char *)"xmlNewProp", libxml_xmlNewProp, METH_VARARGS, NULL },
#endif /* defined(LIBXML_TREE_ENABLED) || defined(LIBXML_HTML_ENABLED) || defined(LIBXML_SCHEMAS_ENABLED) */
    { (char *)"xmlNewReference", libxml_xmlNewReference, METH_VARARGS, NULL },
    { (char *)"xmlNewText", libxml_xmlNewText, METH_VARARGS, NULL },
#if defined(LIBXML_TREE_ENABLED)
    { (char *)"xmlNewTextChild", libxml_xmlNewTextChild, METH_VARARGS, NULL },
#endif /* defined(LIBXML_TREE_ENABLED) */
    { (char *)"xmlNewTextLen", libxml_xmlNewTextLen, METH_VARARGS, NULL },
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlNewTextReader", libxml_xmlNewTextReader, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlNewTextReaderFilename", libxml_xmlNewTextReaderFilename, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_VALID_ENABLED)
    { (char *)"xmlNewValidCtxt", libxml_xmlNewValidCtxt, METH_VARARGS, NULL },
#endif /* defined(LIBXML_VALID_ENABLED) */
    { (char *)"xmlNextChar", libxml_xmlNextChar, METH_VARARGS, NULL },
#if defined(LIBXML_TREE_ENABLED)
    { (char *)"xmlNextElementSibling", libxml_xmlNextElementSibling, METH_VARARGS, NULL },
#endif /* defined(LIBXML_TREE_ENABLED) */
    { (char *)"xmlNodeAddContent", libxml_xmlNodeAddContent, METH_VARARGS, NULL },
    { (char *)"xmlNodeAddContentLen", libxml_xmlNodeAddContentLen, METH_VARARGS, NULL },
#if defined(LIBXML_OUTPUT_ENABLED)
    { (char *)"xmlNodeDumpOutput", libxml_xmlNodeDumpOutput, METH_VARARGS, NULL },
#endif /* defined(LIBXML_OUTPUT_ENABLED) */
    { (char *)"xmlNodeGetBase", libxml_xmlNodeGetBase, METH_VARARGS, NULL },
    { (char *)"xmlNodeGetContent", libxml_xmlNodeGetContent, METH_VARARGS, NULL },
    { (char *)"xmlNodeGetLang", libxml_xmlNodeGetLang, METH_VARARGS, NULL },
    { (char *)"xmlNodeGetNs", libxml_xmlNodeGetNs, METH_VARARGS, NULL },
    { (char *)"xmlNodeGetNsDefs", libxml_xmlNodeGetNsDefs, METH_VARARGS, NULL },
    { (char *)"xmlNodeGetSpacePreserve", libxml_xmlNodeGetSpacePreserve, METH_VARARGS, NULL },
    { (char *)"xmlNodeIsText", libxml_xmlNodeIsText, METH_VARARGS, NULL },
#if defined(LIBXML_TREE_ENABLED)
    { (char *)"xmlNodeListGetRawString", libxml_xmlNodeListGetRawString, METH_VARARGS, NULL },
#endif /* defined(LIBXML_TREE_ENABLED) */
    { (char *)"xmlNodeListGetString", libxml_xmlNodeListGetString, METH_VARARGS, NULL },
#if defined(LIBXML_TREE_ENABLED) || defined(LIBXML_XINCLUDE_ENABLED)
    { (char *)"xmlNodeSetBase", libxml_xmlNodeSetBase, METH_VARARGS, NULL },
#endif /* defined(LIBXML_TREE_ENABLED) || defined(LIBXML_XINCLUDE_ENABLED) */
    { (char *)"xmlNodeSetContent", libxml_xmlNodeSetContent, METH_VARARGS, NULL },
#if defined(LIBXML_TREE_ENABLED)
    { (char *)"xmlNodeSetContentLen", libxml_xmlNodeSetContentLen, METH_VARARGS, NULL },
#endif /* defined(LIBXML_TREE_ENABLED) */
#if defined(LIBXML_TREE_ENABLED)
    { (char *)"xmlNodeSetLang", libxml_xmlNodeSetLang, METH_VARARGS, NULL },
#endif /* defined(LIBXML_TREE_ENABLED) */
#if defined(LIBXML_TREE_ENABLED)
    { (char *)"xmlNodeSetName", libxml_xmlNodeSetName, METH_VARARGS, NULL },
#endif /* defined(LIBXML_TREE_ENABLED) */
#if defined(LIBXML_TREE_ENABLED)
    { (char *)"xmlNodeSetSpacePreserve", libxml_xmlNodeSetSpacePreserve, METH_VARARGS, NULL },
#endif /* defined(LIBXML_TREE_ENABLED) */
    { (char *)"xmlNormalizeURIPath", libxml_xmlNormalizeURIPath, METH_VARARGS, NULL },
    { (char *)"xmlNormalizeWindowsPath", libxml_xmlNormalizeWindowsPath, METH_VARARGS, NULL },
#if defined(LIBXML_OUTPUT_ENABLED)
    { (char *)"xmlOutputBufferGetContent", libxml_xmlOutputBufferGetContent, METH_VARARGS, NULL },
#endif /* defined(LIBXML_OUTPUT_ENABLED) */
#if defined(LIBXML_OUTPUT_ENABLED)
    { (char *)"xmlOutputBufferWrite", libxml_xmlOutputBufferWrite, METH_VARARGS, NULL },
#endif /* defined(LIBXML_OUTPUT_ENABLED) */
#if defined(LIBXML_OUTPUT_ENABLED)
    { (char *)"xmlOutputBufferWriteString", libxml_xmlOutputBufferWriteString, METH_VARARGS, NULL },
#endif /* defined(LIBXML_OUTPUT_ENABLED) */
    { (char *)"xmlParseAttValue", libxml_xmlParseAttValue, METH_VARARGS, NULL },
    { (char *)"xmlParseAttributeListDecl", libxml_xmlParseAttributeListDecl, METH_VARARGS, NULL },
    { (char *)"xmlParseCDSect", libxml_xmlParseCDSect, METH_VARARGS, NULL },
#if defined(LIBXML_CATALOG_ENABLED)
    { (char *)"xmlParseCatalogFile", libxml_xmlParseCatalogFile, METH_VARARGS, NULL },
#endif /* defined(LIBXML_CATALOG_ENABLED) */
    { (char *)"xmlParseCharData", libxml_xmlParseCharData, METH_VARARGS, NULL },
    { (char *)"xmlParseCharRef", libxml_xmlParseCharRef, METH_VARARGS, NULL },
#if defined(LIBXML_PUSH_ENABLED)
    { (char *)"xmlParseChunk", libxml_xmlParseChunk, METH_VARARGS, NULL },
#endif /* defined(LIBXML_PUSH_ENABLED) */
    { (char *)"xmlParseComment", libxml_xmlParseComment, METH_VARARGS, NULL },
    { (char *)"xmlParseContent", libxml_xmlParseContent, METH_VARARGS, NULL },
#if defined(LIBXML_VALID_ENABLED)
    { (char *)"xmlParseDTD", libxml_xmlParseDTD, METH_VARARGS, NULL },
#endif /* defined(LIBXML_VALID_ENABLED) */
#if defined(LIBXML_SAX1_ENABLED)
    { (char *)"xmlParseDoc", libxml_xmlParseDoc, METH_VARARGS, NULL },
#endif /* defined(LIBXML_SAX1_ENABLED) */
    { (char *)"xmlParseDocTypeDecl", libxml_xmlParseDocTypeDecl, METH_VARARGS, NULL },
    { (char *)"xmlParseDocument", libxml_xmlParseDocument, METH_VARARGS, NULL },
    { (char *)"xmlParseElement", libxml_xmlParseElement, METH_VARARGS, NULL },
    { (char *)"xmlParseElementDecl", libxml_xmlParseElementDecl, METH_VARARGS, NULL },
    { (char *)"xmlParseEncName", libxml_xmlParseEncName, METH_VARARGS, NULL },
    { (char *)"xmlParseEncodingDecl", libxml_xmlParseEncodingDecl, METH_VARARGS, NULL },
#if defined(LIBXML_SAX1_ENABLED)
    { (char *)"xmlParseEndTag", libxml_xmlParseEndTag, METH_VARARGS, NULL },
#endif /* defined(LIBXML_SAX1_ENABLED) */
#if defined(LIBXML_SAX1_ENABLED)
    { (char *)"xmlParseEntity", libxml_xmlParseEntity, METH_VARARGS, NULL },
#endif /* defined(LIBXML_SAX1_ENABLED) */
    { (char *)"xmlParseEntityDecl", libxml_xmlParseEntityDecl, METH_VARARGS, NULL },
    { (char *)"xmlParseEntityRef", libxml_xmlParseEntityRef, METH_VARARGS, NULL },
    { (char *)"xmlParseExtParsedEnt", libxml_xmlParseExtParsedEnt, METH_VARARGS, NULL },
    { (char *)"xmlParseExternalSubset", libxml_xmlParseExternalSubset, METH_VARARGS, NULL },
#if defined(LIBXML_SAX1_ENABLED)
    { (char *)"xmlParseFile", libxml_xmlParseFile, METH_VARARGS, NULL },
#endif /* defined(LIBXML_SAX1_ENABLED) */
    { (char *)"xmlParseMarkupDecl", libxml_xmlParseMarkupDecl, METH_VARARGS, NULL },
#if defined(LIBXML_SAX1_ENABLED)
    { (char *)"xmlParseMemory", libxml_xmlParseMemory, METH_VARARGS, NULL },
#endif /* defined(LIBXML_SAX1_ENABLED) */
    { (char *)"xmlParseMisc", libxml_xmlParseMisc, METH_VARARGS, NULL },
    { (char *)"xmlParseName", libxml_xmlParseName, METH_VARARGS, NULL },
#if defined(LIBXML_LEGACY_ENABLED)
    { (char *)"xmlParseNamespace", libxml_xmlParseNamespace, METH_VARARGS, NULL },
#endif /* defined(LIBXML_LEGACY_ENABLED) */
    { (char *)"xmlParseNmtoken", libxml_xmlParseNmtoken, METH_VARARGS, NULL },
    { (char *)"xmlParseNotationDecl", libxml_xmlParseNotationDecl, METH_VARARGS, NULL },
    { (char *)"xmlParsePEReference", libxml_xmlParsePEReference, METH_VARARGS, NULL },
    { (char *)"xmlParsePI", libxml_xmlParsePI, METH_VARARGS, NULL },
    { (char *)"xmlParsePITarget", libxml_xmlParsePITarget, METH_VARARGS, NULL },
    { (char *)"xmlParsePubidLiteral", libxml_xmlParsePubidLiteral, METH_VARARGS, NULL },
#if defined(LIBXML_LEGACY_ENABLED)
    { (char *)"xmlParseQuotedString", libxml_xmlParseQuotedString, METH_VARARGS, NULL },
#endif /* defined(LIBXML_LEGACY_ENABLED) */
    { (char *)"xmlParseReference", libxml_xmlParseReference, METH_VARARGS, NULL },
    { (char *)"xmlParseSDDecl", libxml_xmlParseSDDecl, METH_VARARGS, NULL },
#if defined(LIBXML_SAX1_ENABLED)
    { (char *)"xmlParseStartTag", libxml_xmlParseStartTag, METH_VARARGS, NULL },
#endif /* defined(LIBXML_SAX1_ENABLED) */
    { (char *)"xmlParseSystemLiteral", libxml_xmlParseSystemLiteral, METH_VARARGS, NULL },
    { (char *)"xmlParseTextDecl", libxml_xmlParseTextDecl, METH_VARARGS, NULL },
    { (char *)"xmlParseURI", libxml_xmlParseURI, METH_VARARGS, NULL },
    { (char *)"xmlParseURIRaw", libxml_xmlParseURIRaw, METH_VARARGS, NULL },
    { (char *)"xmlParseURIReference", libxml_xmlParseURIReference, METH_VARARGS, NULL },
    { (char *)"xmlParseVersionInfo", libxml_xmlParseVersionInfo, METH_VARARGS, NULL },
    { (char *)"xmlParseVersionNum", libxml_xmlParseVersionNum, METH_VARARGS, NULL },
    { (char *)"xmlParseXMLDecl", libxml_xmlParseXMLDecl, METH_VARARGS, NULL },
    { (char *)"xmlParserGetDirectory", libxml_xmlParserGetDirectory, METH_VARARGS, NULL },
    { (char *)"xmlParserGetDoc", libxml_xmlParserGetDoc, METH_VARARGS, NULL },
    { (char *)"xmlParserGetIsValid", libxml_xmlParserGetIsValid, METH_VARARGS, NULL },
    { (char *)"xmlParserGetWellFormed", libxml_xmlParserGetWellFormed, METH_VARARGS, NULL },
    { (char *)"xmlParserHandlePEReference", libxml_xmlParserHandlePEReference, METH_VARARGS, NULL },
#if defined(LIBXML_LEGACY_ENABLED)
    { (char *)"xmlParserHandleReference", libxml_xmlParserHandleReference, METH_VARARGS, NULL },
#endif /* defined(LIBXML_LEGACY_ENABLED) */
    { (char *)"xmlParserInputBufferGrow", libxml_xmlParserInputBufferGrow, METH_VARARGS, NULL },
    { (char *)"xmlParserInputBufferPush", libxml_xmlParserInputBufferPush, METH_VARARGS, NULL },
    { (char *)"xmlParserInputBufferRead", libxml_xmlParserInputBufferRead, METH_VARARGS, NULL },
    { (char *)"xmlParserSetLineNumbers", libxml_xmlParserSetLineNumbers, METH_VARARGS, NULL },
    { (char *)"xmlParserSetLoadSubset", libxml_xmlParserSetLoadSubset, METH_VARARGS, NULL },
    { (char *)"xmlParserSetPedantic", libxml_xmlParserSetPedantic, METH_VARARGS, NULL },
    { (char *)"xmlParserSetReplaceEntities", libxml_xmlParserSetReplaceEntities, METH_VARARGS, NULL },
    { (char *)"xmlParserSetValidate", libxml_xmlParserSetValidate, METH_VARARGS, NULL },
    { (char *)"xmlPathToURI", libxml_xmlPathToURI, METH_VARARGS, NULL },
    { (char *)"xmlPedanticParserDefault", libxml_xmlPedanticParserDefault, METH_VARARGS, NULL },
    { (char *)"xmlPopInput", libxml_xmlPopInput, METH_VARARGS, NULL },
#if defined(LIBXML_TREE_ENABLED)
    { (char *)"xmlPreviousElementSibling", libxml_xmlPreviousElementSibling, METH_VARARGS, NULL },
#endif /* defined(LIBXML_TREE_ENABLED) */
    { (char *)"xmlPrintURI", libxml_xmlPrintURI, METH_VARARGS, NULL },
    { (char *)"xmlPythonCleanupParser", libxml_xmlPythonCleanupParser, METH_VARARGS, NULL },
    { (char *)"xmlReadDoc", libxml_xmlReadDoc, METH_VARARGS, NULL },
    { (char *)"xmlReadFd", libxml_xmlReadFd, METH_VARARGS, NULL },
    { (char *)"xmlReadFile", libxml_xmlReadFile, METH_VARARGS, NULL },
    { (char *)"xmlReadMemory", libxml_xmlReadMemory, METH_VARARGS, NULL },
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlReaderForDoc", libxml_xmlReaderForDoc, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlReaderForFd", libxml_xmlReaderForFd, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlReaderForFile", libxml_xmlReaderForFile, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlReaderForMemory", libxml_xmlReaderForMemory, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlReaderNewDoc", libxml_xmlReaderNewDoc, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlReaderNewFd", libxml_xmlReaderNewFd, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlReaderNewFile", libxml_xmlReaderNewFile, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlReaderNewMemory", libxml_xmlReaderNewMemory, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlReaderNewWalker", libxml_xmlReaderNewWalker, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlReaderWalker", libxml_xmlReaderWalker, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_TREE_ENABLED)
    { (char *)"xmlReconciliateNs", libxml_xmlReconciliateNs, METH_VARARGS, NULL },
#endif /* defined(LIBXML_TREE_ENABLED) */
#if defined(LIBXML_SAX1_ENABLED)
    { (char *)"xmlRecoverDoc", libxml_xmlRecoverDoc, METH_VARARGS, NULL },
#endif /* defined(LIBXML_SAX1_ENABLED) */
#if defined(LIBXML_SAX1_ENABLED)
    { (char *)"xmlRecoverFile", libxml_xmlRecoverFile, METH_VARARGS, NULL },
#endif /* defined(LIBXML_SAX1_ENABLED) */
#if defined(LIBXML_SAX1_ENABLED)
    { (char *)"xmlRecoverMemory", libxml_xmlRecoverMemory, METH_VARARGS, NULL },
#endif /* defined(LIBXML_SAX1_ENABLED) */
#if defined(LIBXML_REGEXP_ENABLED)
    { (char *)"xmlRegFreeRegexp", libxml_xmlRegFreeRegexp, METH_VARARGS, NULL },
#endif /* defined(LIBXML_REGEXP_ENABLED) */
#if defined(LIBXML_REGEXP_ENABLED)
    { (char *)"xmlRegexpCompile", libxml_xmlRegexpCompile, METH_VARARGS, NULL },
#endif /* defined(LIBXML_REGEXP_ENABLED) */
#if defined(LIBXML_REGEXP_ENABLED)
    { (char *)"xmlRegexpExec", libxml_xmlRegexpExec, METH_VARARGS, NULL },
#endif /* defined(LIBXML_REGEXP_ENABLED) */
#if defined(LIBXML_REGEXP_ENABLED)
    { (char *)"xmlRegexpIsDeterminist", libxml_xmlRegexpIsDeterminist, METH_VARARGS, NULL },
#endif /* defined(LIBXML_REGEXP_ENABLED) */
#if defined(LIBXML_REGEXP_ENABLED)
    { (char *)"xmlRegexpPrint", libxml_xmlRegexpPrint, METH_VARARGS, NULL },
#endif /* defined(LIBXML_REGEXP_ENABLED) */
    { (char *)"xmlRegisterDefaultInputCallbacks", libxml_xmlRegisterDefaultInputCallbacks, METH_VARARGS, NULL },
#if defined(LIBXML_OUTPUT_ENABLED)
    { (char *)"xmlRegisterDefaultOutputCallbacks", libxml_xmlRegisterDefaultOutputCallbacks, METH_VARARGS, NULL },
#endif /* defined(LIBXML_OUTPUT_ENABLED) */
#if defined(LIBXML_OUTPUT_ENABLED) && defined(LIBXML_HTTP_ENABLED)
    { (char *)"xmlRegisterHTTPPostCallbacks", libxml_xmlRegisterHTTPPostCallbacks, METH_VARARGS, NULL },
#endif /* defined(LIBXML_OUTPUT_ENABLED) && defined(LIBXML_HTTP_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlRegisterXPathFunction", libxml_xmlRegisterXPathFunction, METH_VARARGS, NULL },
#endif
#if defined(LIBXML_SCHEMAS_ENABLED)
    { (char *)"xmlRelaxNGCleanupTypes", libxml_xmlRelaxNGCleanupTypes, METH_VARARGS, NULL },
#endif /* defined(LIBXML_SCHEMAS_ENABLED) */
#if defined(LIBXML_SCHEMAS_ENABLED) && defined(LIBXML_OUTPUT_ENABLED)
    { (char *)"xmlRelaxNGDump", libxml_xmlRelaxNGDump, METH_VARARGS, NULL },
#endif /* defined(LIBXML_SCHEMAS_ENABLED) && defined(LIBXML_OUTPUT_ENABLED) */
#if defined(LIBXML_SCHEMAS_ENABLED) && defined(LIBXML_OUTPUT_ENABLED)
    { (char *)"xmlRelaxNGDumpTree", libxml_xmlRelaxNGDumpTree, METH_VARARGS, NULL },
#endif /* defined(LIBXML_SCHEMAS_ENABLED) && defined(LIBXML_OUTPUT_ENABLED) */
#if defined(LIBXML_SCHEMAS_ENABLED)
    { (char *)"xmlRelaxNGFree", libxml_xmlRelaxNGFree, METH_VARARGS, NULL },
#endif /* defined(LIBXML_SCHEMAS_ENABLED) */
#if defined(LIBXML_SCHEMAS_ENABLED)
    { (char *)"xmlRelaxNGFreeParserCtxt", libxml_xmlRelaxNGFreeParserCtxt, METH_VARARGS, NULL },
#endif /* defined(LIBXML_SCHEMAS_ENABLED) */
#if defined(LIBXML_SCHEMAS_ENABLED)
    { (char *)"xmlRelaxNGInitTypes", libxml_xmlRelaxNGInitTypes, METH_VARARGS, NULL },
#endif /* defined(LIBXML_SCHEMAS_ENABLED) */
#if defined(LIBXML_SCHEMAS_ENABLED)
    { (char *)"xmlRelaxNGNewDocParserCtxt", libxml_xmlRelaxNGNewDocParserCtxt, METH_VARARGS, NULL },
#endif /* defined(LIBXML_SCHEMAS_ENABLED) */
#if defined(LIBXML_SCHEMAS_ENABLED)
    { (char *)"xmlRelaxNGNewMemParserCtxt", libxml_xmlRelaxNGNewMemParserCtxt, METH_VARARGS, NULL },
#endif /* defined(LIBXML_SCHEMAS_ENABLED) */
#if defined(LIBXML_SCHEMAS_ENABLED)
    { (char *)"xmlRelaxNGNewParserCtxt", libxml_xmlRelaxNGNewParserCtxt, METH_VARARGS, NULL },
#endif /* defined(LIBXML_SCHEMAS_ENABLED) */
#if defined(LIBXML_SCHEMAS_ENABLED)
    { (char *)"xmlRelaxNGNewValidCtxt", libxml_xmlRelaxNGNewValidCtxt, METH_VARARGS, NULL },
#endif /* defined(LIBXML_SCHEMAS_ENABLED) */
#if defined(LIBXML_SCHEMAS_ENABLED)
    { (char *)"xmlRelaxNGParse", libxml_xmlRelaxNGParse, METH_VARARGS, NULL },
#endif /* defined(LIBXML_SCHEMAS_ENABLED) */
#if defined(LIBXML_SCHEMAS_ENABLED)
    { (char *)"xmlRelaxNGValidateDoc", libxml_xmlRelaxNGValidateDoc, METH_VARARGS, NULL },
#endif /* defined(LIBXML_SCHEMAS_ENABLED) */
#if defined(LIBXML_SCHEMAS_ENABLED)
    { (char *)"xmlRelaxNGValidateFullElement", libxml_xmlRelaxNGValidateFullElement, METH_VARARGS, NULL },
#endif /* defined(LIBXML_SCHEMAS_ENABLED) */
#if defined(LIBXML_SCHEMAS_ENABLED)
    { (char *)"xmlRelaxNGValidatePopElement", libxml_xmlRelaxNGValidatePopElement, METH_VARARGS, NULL },
#endif /* defined(LIBXML_SCHEMAS_ENABLED) */
#if defined(LIBXML_SCHEMAS_ENABLED)
    { (char *)"xmlRelaxNGValidatePushCData", libxml_xmlRelaxNGValidatePushCData, METH_VARARGS, NULL },
#endif /* defined(LIBXML_SCHEMAS_ENABLED) */
#if defined(LIBXML_SCHEMAS_ENABLED)
    { (char *)"xmlRelaxNGValidatePushElement", libxml_xmlRelaxNGValidatePushElement, METH_VARARGS, NULL },
#endif /* defined(LIBXML_SCHEMAS_ENABLED) */
#if defined(LIBXML_SCHEMAS_ENABLED)
    { (char *)"xmlRelaxParserSetFlag", libxml_xmlRelaxParserSetFlag, METH_VARARGS, NULL },
#endif /* defined(LIBXML_SCHEMAS_ENABLED) */
    { (char *)"xmlRemoveID", libxml_xmlRemoveID, METH_VARARGS, NULL },
    { (char *)"xmlRemoveProp", libxml_xmlRemoveProp, METH_VARARGS, NULL },
    { (char *)"xmlRemoveRef", libxml_xmlRemoveRef, METH_VARARGS, NULL },
#if defined(LIBXML_TREE_ENABLED) || defined(LIBXML_WRITER_ENABLED)
    { (char *)"xmlReplaceNode", libxml_xmlReplaceNode, METH_VARARGS, NULL },
#endif /* defined(LIBXML_TREE_ENABLED) || defined(LIBXML_WRITER_ENABLED) */
    { (char *)"xmlResetError", libxml_xmlResetError, METH_VARARGS, NULL },
    { (char *)"xmlResetLastError", libxml_xmlResetLastError, METH_VARARGS, NULL },
#if defined(LIBXML_SAX1_ENABLED)
    { (char *)"xmlSAXDefaultVersion", libxml_xmlSAXDefaultVersion, METH_VARARGS, NULL },
#endif /* defined(LIBXML_SAX1_ENABLED) */
    { (char *)"xmlSAXParseFile", libxml_xmlSAXParseFile, METH_VARARGS, NULL },
#if defined(LIBXML_OUTPUT_ENABLED)
    { (char *)"xmlSaveFile", libxml_xmlSaveFile, METH_VARARGS, NULL },
#endif /* defined(LIBXML_OUTPUT_ENABLED) */
#if defined(LIBXML_OUTPUT_ENABLED)
    { (char *)"xmlSaveFileEnc", libxml_xmlSaveFileEnc, METH_VARARGS, NULL },
#endif /* defined(LIBXML_OUTPUT_ENABLED) */
#if defined(LIBXML_OUTPUT_ENABLED)
    { (char *)"xmlSaveFormatFile", libxml_xmlSaveFormatFile, METH_VARARGS, NULL },
#endif /* defined(LIBXML_OUTPUT_ENABLED) */
#if defined(LIBXML_OUTPUT_ENABLED)
    { (char *)"xmlSaveFormatFileEnc", libxml_xmlSaveFormatFileEnc, METH_VARARGS, NULL },
#endif /* defined(LIBXML_OUTPUT_ENABLED) */
    { (char *)"xmlSaveUri", libxml_xmlSaveUri, METH_VARARGS, NULL },
#if defined(LIBXML_LEGACY_ENABLED)
    { (char *)"xmlScanName", libxml_xmlScanName, METH_VARARGS, NULL },
#endif /* defined(LIBXML_LEGACY_ENABLED) */
#if defined(LIBXML_SCHEMAS_ENABLED)
    { (char *)"xmlSchemaCleanupTypes", libxml_xmlSchemaCleanupTypes, METH_VARARGS, NULL },
#endif /* defined(LIBXML_SCHEMAS_ENABLED) */
#if defined(LIBXML_SCHEMAS_ENABLED)
    { (char *)"xmlSchemaCollapseString", libxml_xmlSchemaCollapseString, METH_VARARGS, NULL },
#endif /* defined(LIBXML_SCHEMAS_ENABLED) */
#if defined(LIBXML_SCHEMAS_ENABLED) && defined(LIBXML_OUTPUT_ENABLED)
    { (char *)"xmlSchemaDump", libxml_xmlSchemaDump, METH_VARARGS, NULL },
#endif /* defined(LIBXML_SCHEMAS_ENABLED) && defined(LIBXML_OUTPUT_ENABLED) */
#if defined(LIBXML_SCHEMAS_ENABLED)
    { (char *)"xmlSchemaFree", libxml_xmlSchemaFree, METH_VARARGS, NULL },
#endif /* defined(LIBXML_SCHEMAS_ENABLED) */
#if defined(LIBXML_SCHEMAS_ENABLED)
    { (char *)"xmlSchemaFreeParserCtxt", libxml_xmlSchemaFreeParserCtxt, METH_VARARGS, NULL },
#endif /* defined(LIBXML_SCHEMAS_ENABLED) */
#if defined(LIBXML_SCHEMAS_ENABLED)
    { (char *)"xmlSchemaInitTypes", libxml_xmlSchemaInitTypes, METH_VARARGS, NULL },
#endif /* defined(LIBXML_SCHEMAS_ENABLED) */
#if defined(LIBXML_SCHEMAS_ENABLED)
    { (char *)"xmlSchemaIsValid", libxml_xmlSchemaIsValid, METH_VARARGS, NULL },
#endif /* defined(LIBXML_SCHEMAS_ENABLED) */
#if defined(LIBXML_SCHEMAS_ENABLED)
    { (char *)"xmlSchemaNewDocParserCtxt", libxml_xmlSchemaNewDocParserCtxt, METH_VARARGS, NULL },
#endif /* defined(LIBXML_SCHEMAS_ENABLED) */
#if defined(LIBXML_SCHEMAS_ENABLED)
    { (char *)"xmlSchemaNewMemParserCtxt", libxml_xmlSchemaNewMemParserCtxt, METH_VARARGS, NULL },
#endif /* defined(LIBXML_SCHEMAS_ENABLED) */
#if defined(LIBXML_SCHEMAS_ENABLED)
    { (char *)"xmlSchemaNewParserCtxt", libxml_xmlSchemaNewParserCtxt, METH_VARARGS, NULL },
#endif /* defined(LIBXML_SCHEMAS_ENABLED) */
#if defined(LIBXML_SCHEMAS_ENABLED)
    { (char *)"xmlSchemaNewValidCtxt", libxml_xmlSchemaNewValidCtxt, METH_VARARGS, NULL },
#endif /* defined(LIBXML_SCHEMAS_ENABLED) */
#if defined(LIBXML_SCHEMAS_ENABLED)
    { (char *)"xmlSchemaParse", libxml_xmlSchemaParse, METH_VARARGS, NULL },
#endif /* defined(LIBXML_SCHEMAS_ENABLED) */
#if defined(LIBXML_SCHEMAS_ENABLED)
    { (char *)"xmlSchemaSetValidOptions", libxml_xmlSchemaSetValidOptions, METH_VARARGS, NULL },
#endif /* defined(LIBXML_SCHEMAS_ENABLED) */
#if defined(LIBXML_SCHEMAS_ENABLED)
    { (char *)"xmlSchemaValidCtxtGetOptions", libxml_xmlSchemaValidCtxtGetOptions, METH_VARARGS, NULL },
#endif /* defined(LIBXML_SCHEMAS_ENABLED) */
#if defined(LIBXML_SCHEMAS_ENABLED)
    { (char *)"xmlSchemaValidCtxtGetParserCtxt", libxml_xmlSchemaValidCtxtGetParserCtxt, METH_VARARGS, NULL },
#endif /* defined(LIBXML_SCHEMAS_ENABLED) */
#if defined(LIBXML_SCHEMAS_ENABLED)
    { (char *)"xmlSchemaValidateDoc", libxml_xmlSchemaValidateDoc, METH_VARARGS, NULL },
#endif /* defined(LIBXML_SCHEMAS_ENABLED) */
#if defined(LIBXML_SCHEMAS_ENABLED)
    { (char *)"xmlSchemaValidateFile", libxml_xmlSchemaValidateFile, METH_VARARGS, NULL },
#endif /* defined(LIBXML_SCHEMAS_ENABLED) */
#if defined(LIBXML_SCHEMAS_ENABLED)
    { (char *)"xmlSchemaValidateOneElement", libxml_xmlSchemaValidateOneElement, METH_VARARGS, NULL },
#endif /* defined(LIBXML_SCHEMAS_ENABLED) */
#if defined(LIBXML_SCHEMAS_ENABLED)
    { (char *)"xmlSchemaValidateSetFilename", libxml_xmlSchemaValidateSetFilename, METH_VARARGS, NULL },
#endif /* defined(LIBXML_SCHEMAS_ENABLED) */
#if defined(LIBXML_SCHEMAS_ENABLED)
    { (char *)"xmlSchemaWhiteSpaceReplace", libxml_xmlSchemaWhiteSpaceReplace, METH_VARARGS, NULL },
#endif /* defined(LIBXML_SCHEMAS_ENABLED) */
    { (char *)"xmlSearchNs", libxml_xmlSearchNs, METH_VARARGS, NULL },
    { (char *)"xmlSearchNsByHref", libxml_xmlSearchNsByHref, METH_VARARGS, NULL },
    { (char *)"xmlSetCompressMode", libxml_xmlSetCompressMode, METH_VARARGS, NULL },
    { (char *)"xmlSetDocCompressMode", libxml_xmlSetDocCompressMode, METH_VARARGS, NULL },
    { (char *)"xmlSetEntityLoader", libxml_xmlSetEntityLoader, METH_VARARGS, NULL },
    { (char *)"xmlSetListDoc", libxml_xmlSetListDoc, METH_VARARGS, NULL },
    { (char *)"xmlSetNs", libxml_xmlSetNs, METH_VARARGS, NULL },
#if defined(LIBXML_TREE_ENABLED) || defined(LIBXML_XINCLUDE_ENABLED) || defined(LIBXML_SCHEMAS_ENABLED) || defined(LIBXML_HTML_ENABLED)
    { (char *)"xmlSetNsProp", libxml_xmlSetNsProp, METH_VARARGS, NULL },
#endif /* defined(LIBXML_TREE_ENABLED) || defined(LIBXML_XINCLUDE_ENABLED) || defined(LIBXML_SCHEMAS_ENABLED) || defined(LIBXML_HTML_ENABLED) */
#if defined(LIBXML_TREE_ENABLED) || defined(LIBXML_XINCLUDE_ENABLED) || defined(LIBXML_SCHEMAS_ENABLED) || defined(LIBXML_HTML_ENABLED)
    { (char *)"xmlSetProp", libxml_xmlSetProp, METH_VARARGS, NULL },
#endif /* defined(LIBXML_TREE_ENABLED) || defined(LIBXML_XINCLUDE_ENABLED) || defined(LIBXML_SCHEMAS_ENABLED) || defined(LIBXML_HTML_ENABLED) */
    { (char *)"xmlSetTreeDoc", libxml_xmlSetTreeDoc, METH_VARARGS, NULL },
#if defined(LIBXML_SAX1_ENABLED)
    { (char *)"xmlSetupParserForBuffer", libxml_xmlSetupParserForBuffer, METH_VARARGS, NULL },
#endif /* defined(LIBXML_SAX1_ENABLED) */
#if defined(LIBXML_DEBUG_ENABLED) && defined(LIBXML_XPATH_ENABLED) && defined(LIBXML_OUTPUT_ENABLED)
    { (char *)"xmlShellPrintNode", libxml_xmlShellPrintNode, METH_VARARGS, NULL },
#endif /* defined(LIBXML_DEBUG_ENABLED) && defined(LIBXML_XPATH_ENABLED) && defined(LIBXML_OUTPUT_ENABLED) */
#if defined(LIBXML_DEBUG_ENABLED) && defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlShellPrintXPathError", libxml_xmlShellPrintXPathError, METH_VARARGS, NULL },
#endif /* defined(LIBXML_DEBUG_ENABLED) && defined(LIBXML_XPATH_ENABLED) */
    { (char *)"xmlSkipBlankChars", libxml_xmlSkipBlankChars, METH_VARARGS, NULL },
    { (char *)"xmlStopParser", libxml_xmlStopParser, METH_VARARGS, NULL },
    { (char *)"xmlStrEqual", libxml_xmlStrEqual, METH_VARARGS, NULL },
    { (char *)"xmlStrQEqual", libxml_xmlStrQEqual, METH_VARARGS, NULL },
    { (char *)"xmlStrcasecmp", libxml_xmlStrcasecmp, METH_VARARGS, NULL },
    { (char *)"xmlStrcasestr", libxml_xmlStrcasestr, METH_VARARGS, NULL },
    { (char *)"xmlStrcat", libxml_xmlStrcat, METH_VARARGS, NULL },
    { (char *)"xmlStrchr", libxml_xmlStrchr, METH_VARARGS, NULL },
    { (char *)"xmlStrcmp", libxml_xmlStrcmp, METH_VARARGS, NULL },
    { (char *)"xmlStrdup", libxml_xmlStrdup, METH_VARARGS, NULL },
    { (char *)"xmlStringDecodeEntities", libxml_xmlStringDecodeEntities, METH_VARARGS, NULL },
    { (char *)"xmlStringGetNodeList", libxml_xmlStringGetNodeList, METH_VARARGS, NULL },
    { (char *)"xmlStringLenDecodeEntities", libxml_xmlStringLenDecodeEntities, METH_VARARGS, NULL },
    { (char *)"xmlStringLenGetNodeList", libxml_xmlStringLenGetNodeList, METH_VARARGS, NULL },
    { (char *)"xmlStrlen", libxml_xmlStrlen, METH_VARARGS, NULL },
    { (char *)"xmlStrncasecmp", libxml_xmlStrncasecmp, METH_VARARGS, NULL },
    { (char *)"xmlStrncat", libxml_xmlStrncat, METH_VARARGS, NULL },
    { (char *)"xmlStrncatNew", libxml_xmlStrncatNew, METH_VARARGS, NULL },
    { (char *)"xmlStrncmp", libxml_xmlStrncmp, METH_VARARGS, NULL },
    { (char *)"xmlStrndup", libxml_xmlStrndup, METH_VARARGS, NULL },
    { (char *)"xmlStrstr", libxml_xmlStrstr, METH_VARARGS, NULL },
    { (char *)"xmlStrsub", libxml_xmlStrsub, METH_VARARGS, NULL },
    { (char *)"xmlSubstituteEntitiesDefault", libxml_xmlSubstituteEntitiesDefault, METH_VARARGS, NULL },
    { (char *)"xmlTextConcat", libxml_xmlTextConcat, METH_VARARGS, NULL },
    { (char *)"xmlTextMerge", libxml_xmlTextMerge, METH_VARARGS, NULL },
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlTextReaderAttributeCount", libxml_xmlTextReaderAttributeCount, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlTextReaderByteConsumed", libxml_xmlTextReaderByteConsumed, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlTextReaderClose", libxml_xmlTextReaderClose, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlTextReaderConstBaseUri", libxml_xmlTextReaderConstBaseUri, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlTextReaderConstEncoding", libxml_xmlTextReaderConstEncoding, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlTextReaderConstLocalName", libxml_xmlTextReaderConstLocalName, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlTextReaderConstName", libxml_xmlTextReaderConstName, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlTextReaderConstNamespaceUri", libxml_xmlTextReaderConstNamespaceUri, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlTextReaderConstPrefix", libxml_xmlTextReaderConstPrefix, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlTextReaderConstString", libxml_xmlTextReaderConstString, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlTextReaderConstValue", libxml_xmlTextReaderConstValue, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlTextReaderConstXmlLang", libxml_xmlTextReaderConstXmlLang, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlTextReaderConstXmlVersion", libxml_xmlTextReaderConstXmlVersion, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlTextReaderCurrentDoc", libxml_xmlTextReaderCurrentDoc, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlTextReaderCurrentNode", libxml_xmlTextReaderCurrentNode, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlTextReaderDepth", libxml_xmlTextReaderDepth, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlTextReaderExpand", libxml_xmlTextReaderExpand, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlTextReaderGetAttribute", libxml_xmlTextReaderGetAttribute, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlTextReaderGetAttributeNo", libxml_xmlTextReaderGetAttributeNo, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlTextReaderGetAttributeNs", libxml_xmlTextReaderGetAttributeNs, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlTextReaderGetParserColumnNumber", libxml_xmlTextReaderGetParserColumnNumber, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlTextReaderGetParserLineNumber", libxml_xmlTextReaderGetParserLineNumber, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlTextReaderGetParserProp", libxml_xmlTextReaderGetParserProp, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlTextReaderGetRemainder", libxml_xmlTextReaderGetRemainder, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlTextReaderHasAttributes", libxml_xmlTextReaderHasAttributes, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlTextReaderHasValue", libxml_xmlTextReaderHasValue, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlTextReaderIsDefault", libxml_xmlTextReaderIsDefault, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlTextReaderIsEmptyElement", libxml_xmlTextReaderIsEmptyElement, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlTextReaderIsNamespaceDecl", libxml_xmlTextReaderIsNamespaceDecl, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlTextReaderIsValid", libxml_xmlTextReaderIsValid, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlTextReaderLocatorBaseURI", libxml_xmlTextReaderLocatorBaseURI, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlTextReaderLocatorLineNumber", libxml_xmlTextReaderLocatorLineNumber, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlTextReaderLookupNamespace", libxml_xmlTextReaderLookupNamespace, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlTextReaderMoveToAttribute", libxml_xmlTextReaderMoveToAttribute, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlTextReaderMoveToAttributeNo", libxml_xmlTextReaderMoveToAttributeNo, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlTextReaderMoveToAttributeNs", libxml_xmlTextReaderMoveToAttributeNs, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlTextReaderMoveToElement", libxml_xmlTextReaderMoveToElement, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlTextReaderMoveToFirstAttribute", libxml_xmlTextReaderMoveToFirstAttribute, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlTextReaderMoveToNextAttribute", libxml_xmlTextReaderMoveToNextAttribute, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlTextReaderNext", libxml_xmlTextReaderNext, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlTextReaderNextSibling", libxml_xmlTextReaderNextSibling, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlTextReaderNodeType", libxml_xmlTextReaderNodeType, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlTextReaderNormalization", libxml_xmlTextReaderNormalization, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlTextReaderPreserve", libxml_xmlTextReaderPreserve, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlTextReaderQuoteChar", libxml_xmlTextReaderQuoteChar, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlTextReaderRead", libxml_xmlTextReaderRead, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlTextReaderReadAttributeValue", libxml_xmlTextReaderReadAttributeValue, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED) && defined(LIBXML_WRITER_ENABLED)
    { (char *)"xmlTextReaderReadInnerXml", libxml_xmlTextReaderReadInnerXml, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) && defined(LIBXML_WRITER_ENABLED) */
#if defined(LIBXML_READER_ENABLED) && defined(LIBXML_WRITER_ENABLED)
    { (char *)"xmlTextReaderReadOuterXml", libxml_xmlTextReaderReadOuterXml, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) && defined(LIBXML_WRITER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlTextReaderReadState", libxml_xmlTextReaderReadState, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlTextReaderReadString", libxml_xmlTextReaderReadString, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED) && defined(LIBXML_SCHEMAS_ENABLED)
    { (char *)"xmlTextReaderRelaxNGSetSchema", libxml_xmlTextReaderRelaxNGSetSchema, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) && defined(LIBXML_SCHEMAS_ENABLED) */
#if defined(LIBXML_READER_ENABLED) && defined(LIBXML_SCHEMAS_ENABLED)
    { (char *)"xmlTextReaderRelaxNGValidate", libxml_xmlTextReaderRelaxNGValidate, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) && defined(LIBXML_SCHEMAS_ENABLED) */
#if defined(LIBXML_READER_ENABLED) && defined(LIBXML_SCHEMAS_ENABLED)
    { (char *)"xmlTextReaderRelaxNGValidateCtxt", libxml_xmlTextReaderRelaxNGValidateCtxt, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) && defined(LIBXML_SCHEMAS_ENABLED) */
#if defined(LIBXML_READER_ENABLED) && defined(LIBXML_SCHEMAS_ENABLED)
    { (char *)"xmlTextReaderSchemaValidate", libxml_xmlTextReaderSchemaValidate, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) && defined(LIBXML_SCHEMAS_ENABLED) */
#if defined(LIBXML_READER_ENABLED) && defined(LIBXML_SCHEMAS_ENABLED)
    { (char *)"xmlTextReaderSchemaValidateCtxt", libxml_xmlTextReaderSchemaValidateCtxt, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) && defined(LIBXML_SCHEMAS_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlTextReaderSetParserProp", libxml_xmlTextReaderSetParserProp, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED) && defined(LIBXML_SCHEMAS_ENABLED)
    { (char *)"xmlTextReaderSetSchema", libxml_xmlTextReaderSetSchema, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) && defined(LIBXML_SCHEMAS_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlTextReaderSetup", libxml_xmlTextReaderSetup, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
#if defined(LIBXML_READER_ENABLED)
    { (char *)"xmlTextReaderStandalone", libxml_xmlTextReaderStandalone, METH_VARARGS, NULL },
#endif /* defined(LIBXML_READER_ENABLED) */
    { (char *)"xmlThrDefDefaultBufferSize", libxml_xmlThrDefDefaultBufferSize, METH_VARARGS, NULL },
    { (char *)"xmlThrDefDoValidityCheckingDefaultValue", libxml_xmlThrDefDoValidityCheckingDefaultValue, METH_VARARGS, NULL },
    { (char *)"xmlThrDefGetWarningsDefaultValue", libxml_xmlThrDefGetWarningsDefaultValue, METH_VARARGS, NULL },
    { (char *)"xmlThrDefIndentTreeOutput", libxml_xmlThrDefIndentTreeOutput, METH_VARARGS, NULL },
    { (char *)"xmlThrDefKeepBlanksDefaultValue", libxml_xmlThrDefKeepBlanksDefaultValue, METH_VARARGS, NULL },
    { (char *)"xmlThrDefLineNumbersDefaultValue", libxml_xmlThrDefLineNumbersDefaultValue, METH_VARARGS, NULL },
    { (char *)"xmlThrDefLoadExtDtdDefaultValue", libxml_xmlThrDefLoadExtDtdDefaultValue, METH_VARARGS, NULL },
    { (char *)"xmlThrDefParserDebugEntities", libxml_xmlThrDefParserDebugEntities, METH_VARARGS, NULL },
    { (char *)"xmlThrDefPedanticParserDefaultValue", libxml_xmlThrDefPedanticParserDefaultValue, METH_VARARGS, NULL },
    { (char *)"xmlThrDefSaveNoEmptyTags", libxml_xmlThrDefSaveNoEmptyTags, METH_VARARGS, NULL },
    { (char *)"xmlThrDefSubstituteEntitiesDefaultValue", libxml_xmlThrDefSubstituteEntitiesDefaultValue, METH_VARARGS, NULL },
    { (char *)"xmlThrDefTreeIndentString", libxml_xmlThrDefTreeIndentString, METH_VARARGS, NULL },
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsAegeanNumbers", libxml_xmlUCSIsAegeanNumbers, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsAlphabeticPresentationForms", libxml_xmlUCSIsAlphabeticPresentationForms, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsArabic", libxml_xmlUCSIsArabic, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsArabicPresentationFormsA", libxml_xmlUCSIsArabicPresentationFormsA, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsArabicPresentationFormsB", libxml_xmlUCSIsArabicPresentationFormsB, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsArmenian", libxml_xmlUCSIsArmenian, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsArrows", libxml_xmlUCSIsArrows, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsBasicLatin", libxml_xmlUCSIsBasicLatin, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsBengali", libxml_xmlUCSIsBengali, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsBlock", libxml_xmlUCSIsBlock, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsBlockElements", libxml_xmlUCSIsBlockElements, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsBopomofo", libxml_xmlUCSIsBopomofo, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsBopomofoExtended", libxml_xmlUCSIsBopomofoExtended, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsBoxDrawing", libxml_xmlUCSIsBoxDrawing, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsBraillePatterns", libxml_xmlUCSIsBraillePatterns, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsBuhid", libxml_xmlUCSIsBuhid, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsByzantineMusicalSymbols", libxml_xmlUCSIsByzantineMusicalSymbols, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCJKCompatibility", libxml_xmlUCSIsCJKCompatibility, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCJKCompatibilityForms", libxml_xmlUCSIsCJKCompatibilityForms, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCJKCompatibilityIdeographs", libxml_xmlUCSIsCJKCompatibilityIdeographs, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCJKCompatibilityIdeographsSupplement", libxml_xmlUCSIsCJKCompatibilityIdeographsSupplement, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCJKRadicalsSupplement", libxml_xmlUCSIsCJKRadicalsSupplement, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCJKSymbolsandPunctuation", libxml_xmlUCSIsCJKSymbolsandPunctuation, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCJKUnifiedIdeographs", libxml_xmlUCSIsCJKUnifiedIdeographs, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCJKUnifiedIdeographsExtensionA", libxml_xmlUCSIsCJKUnifiedIdeographsExtensionA, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCJKUnifiedIdeographsExtensionB", libxml_xmlUCSIsCJKUnifiedIdeographsExtensionB, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCat", libxml_xmlUCSIsCat, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCatC", libxml_xmlUCSIsCatC, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCatCc", libxml_xmlUCSIsCatCc, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCatCf", libxml_xmlUCSIsCatCf, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCatCo", libxml_xmlUCSIsCatCo, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCatCs", libxml_xmlUCSIsCatCs, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCatL", libxml_xmlUCSIsCatL, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCatLl", libxml_xmlUCSIsCatLl, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCatLm", libxml_xmlUCSIsCatLm, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCatLo", libxml_xmlUCSIsCatLo, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCatLt", libxml_xmlUCSIsCatLt, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCatLu", libxml_xmlUCSIsCatLu, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCatM", libxml_xmlUCSIsCatM, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCatMc", libxml_xmlUCSIsCatMc, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCatMe", libxml_xmlUCSIsCatMe, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCatMn", libxml_xmlUCSIsCatMn, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCatN", libxml_xmlUCSIsCatN, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCatNd", libxml_xmlUCSIsCatNd, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCatNl", libxml_xmlUCSIsCatNl, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCatNo", libxml_xmlUCSIsCatNo, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCatP", libxml_xmlUCSIsCatP, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCatPc", libxml_xmlUCSIsCatPc, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCatPd", libxml_xmlUCSIsCatPd, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCatPe", libxml_xmlUCSIsCatPe, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCatPf", libxml_xmlUCSIsCatPf, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCatPi", libxml_xmlUCSIsCatPi, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCatPo", libxml_xmlUCSIsCatPo, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCatPs", libxml_xmlUCSIsCatPs, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCatS", libxml_xmlUCSIsCatS, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCatSc", libxml_xmlUCSIsCatSc, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCatSk", libxml_xmlUCSIsCatSk, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCatSm", libxml_xmlUCSIsCatSm, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCatSo", libxml_xmlUCSIsCatSo, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCatZ", libxml_xmlUCSIsCatZ, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCatZl", libxml_xmlUCSIsCatZl, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCatZp", libxml_xmlUCSIsCatZp, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCatZs", libxml_xmlUCSIsCatZs, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCherokee", libxml_xmlUCSIsCherokee, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCombiningDiacriticalMarks", libxml_xmlUCSIsCombiningDiacriticalMarks, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCombiningDiacriticalMarksforSymbols", libxml_xmlUCSIsCombiningDiacriticalMarksforSymbols, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCombiningHalfMarks", libxml_xmlUCSIsCombiningHalfMarks, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCombiningMarksforSymbols", libxml_xmlUCSIsCombiningMarksforSymbols, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsControlPictures", libxml_xmlUCSIsControlPictures, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCurrencySymbols", libxml_xmlUCSIsCurrencySymbols, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCypriotSyllabary", libxml_xmlUCSIsCypriotSyllabary, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCyrillic", libxml_xmlUCSIsCyrillic, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsCyrillicSupplement", libxml_xmlUCSIsCyrillicSupplement, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsDeseret", libxml_xmlUCSIsDeseret, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsDevanagari", libxml_xmlUCSIsDevanagari, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsDingbats", libxml_xmlUCSIsDingbats, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsEnclosedAlphanumerics", libxml_xmlUCSIsEnclosedAlphanumerics, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsEnclosedCJKLettersandMonths", libxml_xmlUCSIsEnclosedCJKLettersandMonths, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsEthiopic", libxml_xmlUCSIsEthiopic, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsGeneralPunctuation", libxml_xmlUCSIsGeneralPunctuation, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsGeometricShapes", libxml_xmlUCSIsGeometricShapes, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsGeorgian", libxml_xmlUCSIsGeorgian, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsGothic", libxml_xmlUCSIsGothic, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsGreek", libxml_xmlUCSIsGreek, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsGreekExtended", libxml_xmlUCSIsGreekExtended, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsGreekandCoptic", libxml_xmlUCSIsGreekandCoptic, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsGujarati", libxml_xmlUCSIsGujarati, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsGurmukhi", libxml_xmlUCSIsGurmukhi, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsHalfwidthandFullwidthForms", libxml_xmlUCSIsHalfwidthandFullwidthForms, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsHangulCompatibilityJamo", libxml_xmlUCSIsHangulCompatibilityJamo, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsHangulJamo", libxml_xmlUCSIsHangulJamo, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsHangulSyllables", libxml_xmlUCSIsHangulSyllables, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsHanunoo", libxml_xmlUCSIsHanunoo, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsHebrew", libxml_xmlUCSIsHebrew, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsHighPrivateUseSurrogates", libxml_xmlUCSIsHighPrivateUseSurrogates, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsHighSurrogates", libxml_xmlUCSIsHighSurrogates, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsHiragana", libxml_xmlUCSIsHiragana, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsIPAExtensions", libxml_xmlUCSIsIPAExtensions, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsIdeographicDescriptionCharacters", libxml_xmlUCSIsIdeographicDescriptionCharacters, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsKanbun", libxml_xmlUCSIsKanbun, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsKangxiRadicals", libxml_xmlUCSIsKangxiRadicals, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsKannada", libxml_xmlUCSIsKannada, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsKatakana", libxml_xmlUCSIsKatakana, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsKatakanaPhoneticExtensions", libxml_xmlUCSIsKatakanaPhoneticExtensions, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsKhmer", libxml_xmlUCSIsKhmer, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsKhmerSymbols", libxml_xmlUCSIsKhmerSymbols, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsLao", libxml_xmlUCSIsLao, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsLatin1Supplement", libxml_xmlUCSIsLatin1Supplement, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsLatinExtendedA", libxml_xmlUCSIsLatinExtendedA, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsLatinExtendedAdditional", libxml_xmlUCSIsLatinExtendedAdditional, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsLatinExtendedB", libxml_xmlUCSIsLatinExtendedB, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsLetterlikeSymbols", libxml_xmlUCSIsLetterlikeSymbols, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsLimbu", libxml_xmlUCSIsLimbu, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsLinearBIdeograms", libxml_xmlUCSIsLinearBIdeograms, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsLinearBSyllabary", libxml_xmlUCSIsLinearBSyllabary, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsLowSurrogates", libxml_xmlUCSIsLowSurrogates, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsMalayalam", libxml_xmlUCSIsMalayalam, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsMathematicalAlphanumericSymbols", libxml_xmlUCSIsMathematicalAlphanumericSymbols, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsMathematicalOperators", libxml_xmlUCSIsMathematicalOperators, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsMiscellaneousMathematicalSymbolsA", libxml_xmlUCSIsMiscellaneousMathematicalSymbolsA, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsMiscellaneousMathematicalSymbolsB", libxml_xmlUCSIsMiscellaneousMathematicalSymbolsB, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsMiscellaneousSymbols", libxml_xmlUCSIsMiscellaneousSymbols, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsMiscellaneousSymbolsandArrows", libxml_xmlUCSIsMiscellaneousSymbolsandArrows, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsMiscellaneousTechnical", libxml_xmlUCSIsMiscellaneousTechnical, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsMongolian", libxml_xmlUCSIsMongolian, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsMusicalSymbols", libxml_xmlUCSIsMusicalSymbols, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsMyanmar", libxml_xmlUCSIsMyanmar, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsNumberForms", libxml_xmlUCSIsNumberForms, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsOgham", libxml_xmlUCSIsOgham, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsOldItalic", libxml_xmlUCSIsOldItalic, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsOpticalCharacterRecognition", libxml_xmlUCSIsOpticalCharacterRecognition, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsOriya", libxml_xmlUCSIsOriya, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsOsmanya", libxml_xmlUCSIsOsmanya, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsPhoneticExtensions", libxml_xmlUCSIsPhoneticExtensions, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsPrivateUse", libxml_xmlUCSIsPrivateUse, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsPrivateUseArea", libxml_xmlUCSIsPrivateUseArea, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsRunic", libxml_xmlUCSIsRunic, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsShavian", libxml_xmlUCSIsShavian, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsSinhala", libxml_xmlUCSIsSinhala, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsSmallFormVariants", libxml_xmlUCSIsSmallFormVariants, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsSpacingModifierLetters", libxml_xmlUCSIsSpacingModifierLetters, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsSpecials", libxml_xmlUCSIsSpecials, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsSuperscriptsandSubscripts", libxml_xmlUCSIsSuperscriptsandSubscripts, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsSupplementalArrowsA", libxml_xmlUCSIsSupplementalArrowsA, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsSupplementalArrowsB", libxml_xmlUCSIsSupplementalArrowsB, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsSupplementalMathematicalOperators", libxml_xmlUCSIsSupplementalMathematicalOperators, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsSupplementaryPrivateUseAreaA", libxml_xmlUCSIsSupplementaryPrivateUseAreaA, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsSupplementaryPrivateUseAreaB", libxml_xmlUCSIsSupplementaryPrivateUseAreaB, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsSyriac", libxml_xmlUCSIsSyriac, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsTagalog", libxml_xmlUCSIsTagalog, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsTagbanwa", libxml_xmlUCSIsTagbanwa, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsTags", libxml_xmlUCSIsTags, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsTaiLe", libxml_xmlUCSIsTaiLe, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsTaiXuanJingSymbols", libxml_xmlUCSIsTaiXuanJingSymbols, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsTamil", libxml_xmlUCSIsTamil, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsTelugu", libxml_xmlUCSIsTelugu, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsThaana", libxml_xmlUCSIsThaana, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsThai", libxml_xmlUCSIsThai, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsTibetan", libxml_xmlUCSIsTibetan, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsUgaritic", libxml_xmlUCSIsUgaritic, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsUnifiedCanadianAboriginalSyllabics", libxml_xmlUCSIsUnifiedCanadianAboriginalSyllabics, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsVariationSelectors", libxml_xmlUCSIsVariationSelectors, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsVariationSelectorsSupplement", libxml_xmlUCSIsVariationSelectorsSupplement, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsYiRadicals", libxml_xmlUCSIsYiRadicals, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsYiSyllables", libxml_xmlUCSIsYiSyllables, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
#if defined(LIBXML_UNICODE_ENABLED)
    { (char *)"xmlUCSIsYijingHexagramSymbols", libxml_xmlUCSIsYijingHexagramSymbols, METH_VARARGS, NULL },
#endif /* defined(LIBXML_UNICODE_ENABLED) */
    { (char *)"xmlURIEscape", libxml_xmlURIEscape, METH_VARARGS, NULL },
    { (char *)"xmlURIEscapeStr", libxml_xmlURIEscapeStr, METH_VARARGS, NULL },
    { (char *)"xmlURIGetAuthority", libxml_xmlURIGetAuthority, METH_VARARGS, NULL },
    { (char *)"xmlURIGetFragment", libxml_xmlURIGetFragment, METH_VARARGS, NULL },
    { (char *)"xmlURIGetOpaque", libxml_xmlURIGetOpaque, METH_VARARGS, NULL },
    { (char *)"xmlURIGetPath", libxml_xmlURIGetPath, METH_VARARGS, NULL },
    { (char *)"xmlURIGetPort", libxml_xmlURIGetPort, METH_VARARGS, NULL },
    { (char *)"xmlURIGetQuery", libxml_xmlURIGetQuery, METH_VARARGS, NULL },
    { (char *)"xmlURIGetQueryRaw", libxml_xmlURIGetQueryRaw, METH_VARARGS, NULL },
    { (char *)"xmlURIGetScheme", libxml_xmlURIGetScheme, METH_VARARGS, NULL },
    { (char *)"xmlURIGetServer", libxml_xmlURIGetServer, METH_VARARGS, NULL },
    { (char *)"xmlURIGetUser", libxml_xmlURIGetUser, METH_VARARGS, NULL },
    { (char *)"xmlURISetAuthority", libxml_xmlURISetAuthority, METH_VARARGS, NULL },
    { (char *)"xmlURISetFragment", libxml_xmlURISetFragment, METH_VARARGS, NULL },
    { (char *)"xmlURISetOpaque", libxml_xmlURISetOpaque, METH_VARARGS, NULL },
    { (char *)"xmlURISetPath", libxml_xmlURISetPath, METH_VARARGS, NULL },
    { (char *)"xmlURISetPort", libxml_xmlURISetPort, METH_VARARGS, NULL },
    { (char *)"xmlURISetQuery", libxml_xmlURISetQuery, METH_VARARGS, NULL },
    { (char *)"xmlURISetQueryRaw", libxml_xmlURISetQueryRaw, METH_VARARGS, NULL },
    { (char *)"xmlURISetScheme", libxml_xmlURISetScheme, METH_VARARGS, NULL },
    { (char *)"xmlURISetServer", libxml_xmlURISetServer, METH_VARARGS, NULL },
    { (char *)"xmlURISetUser", libxml_xmlURISetUser, METH_VARARGS, NULL },
    { (char *)"xmlURIUnescapeString", libxml_xmlURIUnescapeString, METH_VARARGS, NULL },
    { (char *)"xmlUTF8Charcmp", libxml_xmlUTF8Charcmp, METH_VARARGS, NULL },
    { (char *)"xmlUTF8Size", libxml_xmlUTF8Size, METH_VARARGS, NULL },
    { (char *)"xmlUTF8Strlen", libxml_xmlUTF8Strlen, METH_VARARGS, NULL },
    { (char *)"xmlUTF8Strloc", libxml_xmlUTF8Strloc, METH_VARARGS, NULL },
    { (char *)"xmlUTF8Strndup", libxml_xmlUTF8Strndup, METH_VARARGS, NULL },
    { (char *)"xmlUTF8Strpos", libxml_xmlUTF8Strpos, METH_VARARGS, NULL },
    { (char *)"xmlUTF8Strsize", libxml_xmlUTF8Strsize, METH_VARARGS, NULL },
    { (char *)"xmlUTF8Strsub", libxml_xmlUTF8Strsub, METH_VARARGS, NULL },
    { (char *)"xmlUnlinkNode", libxml_xmlUnlinkNode, METH_VARARGS, NULL },
#if defined(LIBXML_TREE_ENABLED) || defined(LIBXML_SCHEMAS_ENABLED)
    { (char *)"xmlUnsetNsProp", libxml_xmlUnsetNsProp, METH_VARARGS, NULL },
#endif /* defined(LIBXML_TREE_ENABLED) || defined(LIBXML_SCHEMAS_ENABLED) */
#if defined(LIBXML_TREE_ENABLED) || defined(LIBXML_SCHEMAS_ENABLED)
    { (char *)"xmlUnsetProp", libxml_xmlUnsetProp, METH_VARARGS, NULL },
#endif /* defined(LIBXML_TREE_ENABLED) || defined(LIBXML_SCHEMAS_ENABLED) */
#if defined(LIBXML_VALID_ENABLED)
    { (char *)"xmlValidCtxtNormalizeAttributeValue", libxml_xmlValidCtxtNormalizeAttributeValue, METH_VARARGS, NULL },
#endif /* defined(LIBXML_VALID_ENABLED) */
#if defined(LIBXML_VALID_ENABLED)
    { (char *)"xmlValidNormalizeAttributeValue", libxml_xmlValidNormalizeAttributeValue, METH_VARARGS, NULL },
#endif /* defined(LIBXML_VALID_ENABLED) */
#if defined(LIBXML_VALID_ENABLED)
    { (char *)"xmlValidateDocument", libxml_xmlValidateDocument, METH_VARARGS, NULL },
#endif /* defined(LIBXML_VALID_ENABLED) */
#if defined(LIBXML_VALID_ENABLED)
    { (char *)"xmlValidateDocumentFinal", libxml_xmlValidateDocumentFinal, METH_VARARGS, NULL },
#endif /* defined(LIBXML_VALID_ENABLED) */
#if defined(LIBXML_VALID_ENABLED)
    { (char *)"xmlValidateDtd", libxml_xmlValidateDtd, METH_VARARGS, NULL },
#endif /* defined(LIBXML_VALID_ENABLED) */
#if defined(LIBXML_VALID_ENABLED)
    { (char *)"xmlValidateDtdFinal", libxml_xmlValidateDtdFinal, METH_VARARGS, NULL },
#endif /* defined(LIBXML_VALID_ENABLED) */
#if defined(LIBXML_VALID_ENABLED)
    { (char *)"xmlValidateElement", libxml_xmlValidateElement, METH_VARARGS, NULL },
#endif /* defined(LIBXML_VALID_ENABLED) */
#if defined(LIBXML_TREE_ENABLED) || defined(LIBXML_XPATH_ENABLED) || defined(LIBXML_SCHEMAS_ENABLED) || defined(LIBXML_DEBUG_ENABLED) || defined (LIBXML_HTML_ENABLED) || defined(LIBXML_SAX1_ENABLED) || defined(LIBXML_HTML_ENABLED) || defined(LIBXML_WRITER_ENABLED) || defined(LIBXML_DOCB_ENABLED)
    { (char *)"xmlValidateNCName", libxml_xmlValidateNCName, METH_VARARGS, NULL },
#endif /* defined(LIBXML_TREE_ENABLED) || defined(LIBXML_XPATH_ENABLED) || defined(LIBXML_SCHEMAS_ENABLED) || defined(LIBXML_DEBUG_ENABLED) || defined (LIBXML_HTML_ENABLED) || defined(LIBXML_SAX1_ENABLED) || defined(LIBXML_HTML_ENABLED) || defined(LIBXML_WRITER_ENABLED) || defined(LIBXML_DOCB_ENABLED) */
#if defined(LIBXML_TREE_ENABLED) || defined(LIBXML_SCHEMAS_ENABLED)
    { (char *)"xmlValidateNMToken", libxml_xmlValidateNMToken, METH_VARARGS, NULL },
#endif /* defined(LIBXML_TREE_ENABLED) || defined(LIBXML_SCHEMAS_ENABLED) */
#if defined(LIBXML_TREE_ENABLED) || defined(LIBXML_SCHEMAS_ENABLED)
    { (char *)"xmlValidateName", libxml_xmlValidateName, METH_VARARGS, NULL },
#endif /* defined(LIBXML_TREE_ENABLED) || defined(LIBXML_SCHEMAS_ENABLED) */
#if defined(LIBXML_VALID_ENABLED)
    { (char *)"xmlValidateNameValue", libxml_xmlValidateNameValue, METH_VARARGS, NULL },
#endif /* defined(LIBXML_VALID_ENABLED) */
#if defined(LIBXML_VALID_ENABLED)
    { (char *)"xmlValidateNamesValue", libxml_xmlValidateNamesValue, METH_VARARGS, NULL },
#endif /* defined(LIBXML_VALID_ENABLED) */
#if defined(LIBXML_VALID_ENABLED)
    { (char *)"xmlValidateNmtokenValue", libxml_xmlValidateNmtokenValue, METH_VARARGS, NULL },
#endif /* defined(LIBXML_VALID_ENABLED) */
#if defined(LIBXML_VALID_ENABLED)
    { (char *)"xmlValidateNmtokensValue", libxml_xmlValidateNmtokensValue, METH_VARARGS, NULL },
#endif /* defined(LIBXML_VALID_ENABLED) */
#if defined(LIBXML_VALID_ENABLED) || defined(LIBXML_SCHEMAS_ENABLED)
    { (char *)"xmlValidateNotationUse", libxml_xmlValidateNotationUse, METH_VARARGS, NULL },
#endif /* defined(LIBXML_VALID_ENABLED) || defined(LIBXML_SCHEMAS_ENABLED) */
#if defined(LIBXML_VALID_ENABLED)
    { (char *)"xmlValidateOneAttribute", libxml_xmlValidateOneAttribute, METH_VARARGS, NULL },
#endif /* defined(LIBXML_VALID_ENABLED) */
#if defined(LIBXML_VALID_ENABLED)
    { (char *)"xmlValidateOneElement", libxml_xmlValidateOneElement, METH_VARARGS, NULL },
#endif /* defined(LIBXML_VALID_ENABLED) */
#if defined(LIBXML_VALID_ENABLED)
    { (char *)"xmlValidateOneNamespace", libxml_xmlValidateOneNamespace, METH_VARARGS, NULL },
#endif /* defined(LIBXML_VALID_ENABLED) */
#if defined(LIBXML_VALID_ENABLED) && defined(LIBXML_REGEXP_ENABLED)
    { (char *)"xmlValidatePopElement", libxml_xmlValidatePopElement, METH_VARARGS, NULL },
#endif /* defined(LIBXML_VALID_ENABLED) && defined(LIBXML_REGEXP_ENABLED) */
#if defined(LIBXML_VALID_ENABLED) && defined(LIBXML_REGEXP_ENABLED)
    { (char *)"xmlValidatePushCData", libxml_xmlValidatePushCData, METH_VARARGS, NULL },
#endif /* defined(LIBXML_VALID_ENABLED) && defined(LIBXML_REGEXP_ENABLED) */
#if defined(LIBXML_VALID_ENABLED) && defined(LIBXML_REGEXP_ENABLED)
    { (char *)"xmlValidatePushElement", libxml_xmlValidatePushElement, METH_VARARGS, NULL },
#endif /* defined(LIBXML_VALID_ENABLED) && defined(LIBXML_REGEXP_ENABLED) */
#if defined(LIBXML_TREE_ENABLED) || defined(LIBXML_SCHEMAS_ENABLED)
    { (char *)"xmlValidateQName", libxml_xmlValidateQName, METH_VARARGS, NULL },
#endif /* defined(LIBXML_TREE_ENABLED) || defined(LIBXML_SCHEMAS_ENABLED) */
#if defined(LIBXML_VALID_ENABLED)
    { (char *)"xmlValidateRoot", libxml_xmlValidateRoot, METH_VARARGS, NULL },
#endif /* defined(LIBXML_VALID_ENABLED) */
#if defined(LIBXML_XINCLUDE_ENABLED)
    { (char *)"xmlXIncludeProcess", libxml_xmlXIncludeProcess, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XINCLUDE_ENABLED) */
#if defined(LIBXML_XINCLUDE_ENABLED)
    { (char *)"xmlXIncludeProcessFlags", libxml_xmlXIncludeProcessFlags, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XINCLUDE_ENABLED) */
#if defined(LIBXML_XINCLUDE_ENABLED)
    { (char *)"xmlXIncludeProcessTree", libxml_xmlXIncludeProcessTree, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XINCLUDE_ENABLED) */
#if defined(LIBXML_XINCLUDE_ENABLED)
    { (char *)"xmlXIncludeProcessTreeFlags", libxml_xmlXIncludeProcessTreeFlags, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XINCLUDE_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathAddValues", libxml_xmlXPathAddValues, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathBooleanFunction", libxml_xmlXPathBooleanFunction, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathCastBooleanToNumber", libxml_xmlXPathCastBooleanToNumber, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathCastBooleanToString", libxml_xmlXPathCastBooleanToString, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathCastNodeToNumber", libxml_xmlXPathCastNodeToNumber, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathCastNodeToString", libxml_xmlXPathCastNodeToString, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathCastNumberToBoolean", libxml_xmlXPathCastNumberToBoolean, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathCastNumberToString", libxml_xmlXPathCastNumberToString, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathCastStringToBoolean", libxml_xmlXPathCastStringToBoolean, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathCastStringToNumber", libxml_xmlXPathCastStringToNumber, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathCeilingFunction", libxml_xmlXPathCeilingFunction, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathCmpNodes", libxml_xmlXPathCmpNodes, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathCompareValues", libxml_xmlXPathCompareValues, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathConcatFunction", libxml_xmlXPathConcatFunction, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathContainsFunction", libxml_xmlXPathContainsFunction, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathContextSetCache", libxml_xmlXPathContextSetCache, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathCountFunction", libxml_xmlXPathCountFunction, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathDivValues", libxml_xmlXPathDivValues, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathEqualValues", libxml_xmlXPathEqualValues, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathErr", libxml_xmlXPathErr, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathEval", libxml_xmlXPathEval, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathEvalExpr", libxml_xmlXPathEvalExpr, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathEvalExpression", libxml_xmlXPathEvalExpression, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathFalseFunction", libxml_xmlXPathFalseFunction, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathFloorFunction", libxml_xmlXPathFloorFunction, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathFreeContext", libxml_xmlXPathFreeContext, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathFreeParserContext", libxml_xmlXPathFreeParserContext, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathGetContextDoc", libxml_xmlXPathGetContextDoc, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathGetContextNode", libxml_xmlXPathGetContextNode, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathGetContextPosition", libxml_xmlXPathGetContextPosition, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathGetContextSize", libxml_xmlXPathGetContextSize, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathGetFunction", libxml_xmlXPathGetFunction, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathGetFunctionURI", libxml_xmlXPathGetFunctionURI, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathIdFunction", libxml_xmlXPathIdFunction, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED) || defined(LIBXML_SCHEMAS_ENABLED)
    { (char *)"xmlXPathInit", libxml_xmlXPathInit, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) || defined(LIBXML_SCHEMAS_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED) || defined(LIBXML_SCHEMAS_ENABLED)
    { (char *)"xmlXPathIsInf", libxml_xmlXPathIsInf, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) || defined(LIBXML_SCHEMAS_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED) || defined(LIBXML_SCHEMAS_ENABLED)
    { (char *)"xmlXPathIsNaN", libxml_xmlXPathIsNaN, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) || defined(LIBXML_SCHEMAS_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathIsNodeType", libxml_xmlXPathIsNodeType, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathLangFunction", libxml_xmlXPathLangFunction, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathLastFunction", libxml_xmlXPathLastFunction, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathLocalNameFunction", libxml_xmlXPathLocalNameFunction, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathModValues", libxml_xmlXPathModValues, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathMultValues", libxml_xmlXPathMultValues, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathNamespaceURIFunction", libxml_xmlXPathNamespaceURIFunction, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathNewBoolean", libxml_xmlXPathNewBoolean, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathNewCString", libxml_xmlXPathNewCString, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathNewContext", libxml_xmlXPathNewContext, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathNewFloat", libxml_xmlXPathNewFloat, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathNewNodeSet", libxml_xmlXPathNewNodeSet, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathNewParserContext", libxml_xmlXPathNewParserContext, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathNewString", libxml_xmlXPathNewString, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathNewValueTree", libxml_xmlXPathNewValueTree, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathNextAncestor", libxml_xmlXPathNextAncestor, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathNextAncestorOrSelf", libxml_xmlXPathNextAncestorOrSelf, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathNextAttribute", libxml_xmlXPathNextAttribute, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathNextChild", libxml_xmlXPathNextChild, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathNextDescendant", libxml_xmlXPathNextDescendant, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathNextDescendantOrSelf", libxml_xmlXPathNextDescendantOrSelf, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathNextFollowing", libxml_xmlXPathNextFollowing, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathNextFollowingSibling", libxml_xmlXPathNextFollowingSibling, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathNextNamespace", libxml_xmlXPathNextNamespace, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathNextParent", libxml_xmlXPathNextParent, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathNextPreceding", libxml_xmlXPathNextPreceding, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathNextPrecedingSibling", libxml_xmlXPathNextPrecedingSibling, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathNextSelf", libxml_xmlXPathNextSelf, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathNodeEval", libxml_xmlXPathNodeEval, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathNodeSetFreeNs", libxml_xmlXPathNodeSetFreeNs, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathNormalizeFunction", libxml_xmlXPathNormalizeFunction, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathNotEqualValues", libxml_xmlXPathNotEqualValues, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathNotFunction", libxml_xmlXPathNotFunction, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathNsLookup", libxml_xmlXPathNsLookup, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathNumberFunction", libxml_xmlXPathNumberFunction, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathOrderDocElems", libxml_xmlXPathOrderDocElems, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathParseNCName", libxml_xmlXPathParseNCName, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathParseName", libxml_xmlXPathParseName, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathParserGetContext", libxml_xmlXPathParserGetContext, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathPopBoolean", libxml_xmlXPathPopBoolean, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathPopNumber", libxml_xmlXPathPopNumber, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathPopString", libxml_xmlXPathPopString, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathPositionFunction", libxml_xmlXPathPositionFunction, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathRegisterAllFunctions", libxml_xmlXPathRegisterAllFunctions, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathRegisterNs", libxml_xmlXPathRegisterNs, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathRegisterVariable", libxml_xmlXPathRegisterVariable, METH_VARARGS, NULL },
#endif
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathRegisteredFuncsCleanup", libxml_xmlXPathRegisteredFuncsCleanup, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathRegisteredNsCleanup", libxml_xmlXPathRegisteredNsCleanup, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathRegisteredVariablesCleanup", libxml_xmlXPathRegisteredVariablesCleanup, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathRoot", libxml_xmlXPathRoot, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathRoundFunction", libxml_xmlXPathRoundFunction, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathSetContextDoc", libxml_xmlXPathSetContextDoc, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathSetContextNode", libxml_xmlXPathSetContextNode, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathStartsWithFunction", libxml_xmlXPathStartsWithFunction, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathStringEvalNumber", libxml_xmlXPathStringEvalNumber, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathStringFunction", libxml_xmlXPathStringFunction, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathStringLengthFunction", libxml_xmlXPathStringLengthFunction, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathSubValues", libxml_xmlXPathSubValues, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathSubstringAfterFunction", libxml_xmlXPathSubstringAfterFunction, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathSubstringBeforeFunction", libxml_xmlXPathSubstringBeforeFunction, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathSubstringFunction", libxml_xmlXPathSubstringFunction, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathSumFunction", libxml_xmlXPathSumFunction, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathTranslateFunction", libxml_xmlXPathTranslateFunction, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathTrueFunction", libxml_xmlXPathTrueFunction, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathValueFlipSign", libxml_xmlXPathValueFlipSign, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathVariableLookup", libxml_xmlXPathVariableLookup, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPathVariableLookupNS", libxml_xmlXPathVariableLookupNS, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPATH_ENABLED)
    { (char *)"xmlXPatherror", libxml_xmlXPatherror, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPATH_ENABLED) */
#if defined(LIBXML_XPTR_ENABLED)
    { (char *)"xmlXPtrEval", libxml_xmlXPtrEval, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPTR_ENABLED) */
#if defined(LIBXML_XPTR_ENABLED)
    { (char *)"xmlXPtrEvalRangePredicate", libxml_xmlXPtrEvalRangePredicate, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPTR_ENABLED) */
#if defined(LIBXML_XPTR_ENABLED)
    { (char *)"xmlXPtrNewCollapsedRange", libxml_xmlXPtrNewCollapsedRange, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPTR_ENABLED) */
#if defined(LIBXML_XPTR_ENABLED)
    { (char *)"xmlXPtrNewContext", libxml_xmlXPtrNewContext, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPTR_ENABLED) */
#if defined(LIBXML_XPTR_ENABLED)
    { (char *)"xmlXPtrNewLocationSetNodes", libxml_xmlXPtrNewLocationSetNodes, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPTR_ENABLED) */
#if defined(LIBXML_XPTR_ENABLED)
    { (char *)"xmlXPtrNewRange", libxml_xmlXPtrNewRange, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPTR_ENABLED) */
#if defined(LIBXML_XPTR_ENABLED)
    { (char *)"xmlXPtrNewRangeNodes", libxml_xmlXPtrNewRangeNodes, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPTR_ENABLED) */
#if defined(LIBXML_XPTR_ENABLED)
    { (char *)"xmlXPtrRangeToFunction", libxml_xmlXPtrRangeToFunction, METH_VARARGS, NULL },
#endif /* defined(LIBXML_XPTR_ENABLED) */
